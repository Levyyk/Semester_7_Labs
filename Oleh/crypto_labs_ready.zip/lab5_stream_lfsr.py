"""
Лабораторна робота № 5: Дослідження потокового шифру (LFSR)
Дисципліна: Захист інформації в інфокомунікаціях
Виконавець: студент 3-го курсу НУ «Львівська політехніка»

Графічний інтерфейс (GUI на Tkinter) + консольний режим (--demo).
LFSR: Режим 1 (m=5, період 31), Режим 2 (m=16, період 65535).
Емпірична перевірка періоду, потоковий XOR, двійкове подання, вразливість Two-Time Pad та Crib Dragging.
"""

import sys
import time
import binascii

# Безпечний імпорт Tkinter (G1)
try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, messagebox
    HAS_TKINTER = True
except ImportError:
    HAS_TKINTER = False

# ----------------- КОНСТАНТИ ЗА ЗАМОВЧУВАННЯМ -----------------
DEFAULT_SEED_5 = 0b10001
DEFAULT_SEED_16 = 0xACE1

DEFAULT_TEXT_1 = "Криптографічний захист інформації у бездротових каналах зв'язку."
DEFAULT_TEXT_2 = "Перехоплення конфіденційних повідомлень зловмисником у мережі."

# Рекомендовано слово >= 8 байтів (в UTF-8 українські літери займають по 2 байти)
DEFAULT_CRIB = "інформації"  # 10 літер = 20 байтів у UTF-8


# ----------------- КЛАС УЗАГАЛЬНЕНОГО LFSR -----------------
class LFSR:
    def __init__(self, size: int, taps: list[int], seed: int):
        self.size = size
        self.taps = taps
        mask = (1 << size) - 1
        if seed & mask == 0:
            raise ValueError("Початковий стан LFSR не може бути 0!")
        self.state = seed & mask
        self.initial_state = self.state

    def step(self) -> int:
        output_bit = self.state & 1
        fb = 0
        for tap in self.taps:
            fb ^= ((self.state >> tap) & 1)
        self.state = (self.state >> 1) | (fb << (self.size - 1))
        return output_bit

    def generate_bits(self, count: int) -> list[int]:
        return [self.step() for _ in range(count)]

    def generate_bytes(self, byte_count: int) -> bytes:
        out_bytes = bytearray()
        for _ in range(byte_count):
            byte_val = 0
            for _ in range(8):
                byte_val = (byte_val << 1) | self.step()
            out_bytes.append(byte_val)
        return bytes(out_bytes)

    def reset(self):
        self.state = self.initial_state


def create_lfsr_m5(seed: int = DEFAULT_SEED_5) -> LFSR:
    return LFSR(size=5, taps=[0, 2], seed=seed)


def create_lfsr_m16(seed: int = DEFAULT_SEED_16) -> LFSR:
    return LFSR(size=16, taps=[0, 2, 3, 5], seed=seed)


def measure_lfsr_period(lfsr: LFSR) -> int:
    lfsr.reset()
    start_state = lfsr.state
    period = 0
    while True:
        lfsr.step()
        period += 1
        if lfsr.state == start_state or period > (1 << lfsr.size) + 10:
            break
    lfsr.reset()
    return period


def encrypt_stream(text: str, lfsr: LFSR) -> tuple[bytes, bytes]:
    lfsr.reset()
    pt_bytes = text.encode("utf-8")
    keystream = lfsr.generate_bytes(len(pt_bytes))
    ct_bytes = bytes(p ^ k for p, k in zip(pt_bytes, keystream))
    return ct_bytes, keystream


def decrypt_stream(ciphertext: bytes, lfsr: LFSR) -> str:
    lfsr.reset()
    keystream = lfsr.generate_bytes(len(ciphertext))
    pt_bytes = bytes(c ^ k for c, k in zip(ciphertext, keystream))
    return pt_bytes.decode("utf-8", errors="replace")


def xor_bytes(b1: bytes, b2: bytes) -> bytes:
    min_len = min(len(b1), len(b2))
    return bytes(b1[i] ^ b2[i] for i in range(min_len))


# 4. CRIB DRAGGING АТАКА
def perform_crib_dragging(c1_xor_c2: bytes, crib: str) -> list[dict]:
    """
    Протягує crib по ВСІХ зсувах C1 ⊕ C2 без використання апріорної позиції.
    Критерії відбору кандидатів:
    - Відкидаються крайові неповні байти UTF-8 на стиках символів.
    - Коректно декодується як UTF-8 без помилок.
    - Складається з кирилиці, пробілів та знаків пунктуації.
    - Оцінюється часткою частих українських літер (о, а, н, і, и, т, в, р, е, с).
    """
    crib_bytes = crib.encode("utf-8")
    crib_len = len(crib_bytes)
    total_len = len(c1_xor_c2)

    valid_chars = set("абвгґдеєжзиіїйклмнопрстуфхцчшщьюяАБВГҐДЕЄЖЗИІЇЙКЛМНОПРСТУФХЦЧШЩЬЮЯ '-,.!?:;\n\r")
    frequent_chars = set("оаніитвресОАНІИТВРЕС")

    candidates = []

    for offset in range(total_len - crib_len + 1):
        chunk = c1_xor_c2[offset:offset + crib_len]
        recovered_bytes = xor_bytes(chunk, crib_bytes)

        # Відкидаємо неповні байти UTF-8 на початку і в кінці зрізу
        s = recovered_bytes
        while s and (s[0] & 0xC0 == 0x80):
            s = s[1:]
        while s and (s[-1] & 0xC0 == 0xC0 or s[-1] & 0xE0 == 0xE0):
            s = s[:-1]

        try:
            cand_str = s.decode("utf-8")
        except UnicodeDecodeError:
            continue

        if len(cand_str) >= 3 and all(ch in valid_chars for ch in cand_str):
            score = sum(1 for ch in cand_str if ch in frequent_chars) / max(1, len(cand_str))
            candidates.append({
                "offset": offset,
                "text": cand_str,
                "score": score
            })

    candidates.sort(key=lambda x: x["score"], reverse=True)
    return candidates[:5]


# ----------------- КОНСОЛЬНЕ АВТО-ДЕМО -----------------
def run_auto_demo():
    print("=" * 82)
    print("      АВТОМАТИЧНА ДЕМОНСТРАЦІЯ: ЛАБОРАТОРНА РОБОТА № 5 (ПОТОКОВИЙ ШИФР LFSR)")
    print("=" * 82)

    # 1. Перші 31 біт гами (m=5) та підтвердження періодичності 31-61
    lfsr5 = create_lfsr_m5()
    bits_62 = lfsr5.generate_bits(62)
    bits_1_31 = "".join(str(b) for b in bits_62[:31])
    bits_32_62 = "".join(str(b) for b in bits_62[31:62])

    print("1. ЕМПІРИЧНЕ ДОСЛІДЖЕННЯ ПЕРІОДИЧНОСТІ LFSR (m = 5 біт):")
    print(f"   Перші 31 біт гами (біти 00..30) : {bits_1_31}")
    print(f"   Наступні 31 біт   (біти 31..61) : {bits_32_62}")
    assert bits_1_31 == bits_32_62, "Помилка: біти 31..61 не повторюють біти 0..30!"
    p5 = measure_lfsr_period(lfsr5)
    print(f"   Заміряний період регістра       : T = {p5} (2^5 - 1 = 31)")
    print("✔ [Підтвердження періоду]: Біти 31–61 повністю дублюють біти 0–30 (строгий період 31).")

    # Перевірка періоду m=16
    lfsr16 = create_lfsr_m16()
    p16 = measure_lfsr_period(lfsr16)
    assert p16 == 65535
    print(f"   Період LFSR m=16 біт            : T = {p16} (2^16 - 1 = 65535)")
    print("✔ [Підтвердження m=16]: Регістр m=16 генерує М-послідовність максимальної довжини.")

    # 2. Двійкове подання: перші 4-5 байт тексту, біти гами, біти шифротексту
    print("\n2. ДВІЙКОВЕ ПОДАННЯ ПОТОКОВОГО XOR (перші 4 байти):")
    sample_pt = "Тест"
    sample_pt_bytes = sample_pt.encode("utf-8")[:4]
    lfsr16.reset()
    sample_gamma = lfsr16.generate_bytes(len(sample_pt_bytes))
    sample_ct = bytes(p ^ g for p, g in zip(sample_pt_bytes, sample_gamma))

    p_bin_str = " ".join(f"{b:08b}" for b in sample_pt_bytes)
    g_bin_str = " ".join(f"{b:08b}" for b in sample_gamma)
    c_bin_str = " ".join(f"{b:08b}" for b in sample_ct)

    print(f"   Відкритий текст P (біти) : {p_bin_str}  (HEX: {sample_pt_bytes.hex()})")
    print(f"   Гама шифрування K (біти) : {g_bin_str}  (HEX: {sample_gamma.hex()})")
    print(f"   Шифротекст C      (біти) : {c_bin_str}  (HEX: {sample_ct.hex()})")
    print("✔ [Бітова перевірка]: C_i = P_i ⊕ K_i побітово узгоджено.")

    # 3. Слабкість короткого періоду (40 однакових символів в режимі m=5)
    print("\n3. СЛАБКІСТЬ КОРОТКОГО ПЕРІОДУ (m = 5 біт):")
    text_40 = "A" * 40
    lfsr5.reset()
    ct_40, _ = encrypt_stream(text_40, lfsr5)
    print(f"   Відкритий текст: 40 однакових символів «A» (код 0x41)")
    print(f"   Байт C[0]  = 0x{ct_40[0]:02x} | Байт C[31] = 0x{ct_40[31]:02x} (періодичне повторення)")
    print(f"   Байт C[1]  = 0x{ct_40[1]:02x} | Байт C[32] = 0x{ct_40[32]:02x}")
    print(f"   Байт C[2]  = 0x{ct_40[2]:02x} | Байт C[33] = 0x{ct_40[33]:02x}")
    assert ct_40[0] == ct_40[31] and ct_40[1] == ct_40[32]
    print("✔ [Вразливість короткого періоду]: Шифротекст періодично повторюється кожні 31 байт!")

    # 4. Crib Dragging атака
    print("\n4. СЛІПА АТАКА CRIB DRAGGING (по всіх зсувах без підглядання):")
    lfsr16.reset()
    c1, _ = encrypt_stream(DEFAULT_TEXT_1, lfsr16)
    c2, _ = encrypt_stream(DEFAULT_TEXT_2, lfsr16)
    c1_xor_c2 = xor_bytes(c1, c2)

    crib = DEFAULT_CRIB
    print(f"   Рекомендований Crib (>= 8 байтів): «{crib}» ({len(crib.encode('utf-8'))} байтів у UTF-8)")
    top_candidates = perform_crib_dragging(c1_xor_c2, crib)

    print("----------------------------------------------------------------------------------")
    print(f"{'Ранг':<5} | {'Зсув':<6} | {'Оцінка частот':<15} | {'Розшифрований фрагмент другого тексту'}")
    print("----------------------------------------------------------------------------------")
    for r_idx, cand in enumerate(top_candidates, start=1):
        print(f"#{r_idx:<4} | {cand['offset']:<6} | {cand['score']:<15.2%} | «{cand['text']}»")
    print("----------------------------------------------------------------------------------")

    real_pos_p1 = DEFAULT_TEXT_1.encode("utf-8").find(crib.encode("utf-8"))
    print(f"[Пост-перевірка для звіту]: Справжній зсув слова «{crib}» у тексті P1: байт {real_pos_p1}")
    if top_candidates:
        print(f"Кращий знайдений кандидат має зсув {top_candidates[0]['offset']} з текстом «{top_candidates[0]['text']}».")

    # 5. Чому LFSR слабкий
    print("\n5. ЧОМУ LFSR Є КРИПТОГРАФІЧНО СЛАБКИМ ГЕНЕРАТОРОМ:")
    print("   1. Лінійність: зворотний зв'язок є чисто лінійною операцією XOR над полем GF(2).")
    print("   2. Алгоритм Берлекемпа–Мессі: знаючи лише 2m послідовних бітів гами (для m=16 це")
    print("      всього 32 біти = 4 байти!), зловмисник може за поліноміальний час O(m²) повністю")
    print("      відновити поліном зворотного зв'язку і початковий стан регістра.")
    print("   3. LFSR ніколи не застосовується самостійно в шифруванні без складних нелінійних блоків.")
    print("=" * 82)


# ----------------- ГРАФІЧНИЙ ІНТЕРФЕЙС (GUI TKINTER) -----------------
class LFSRGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Лабораторна робота № 5: Потоковий шифр LFSR (НУ «Львівська політехніка»)")
        self.root.geometry("920x820")
        self.root.minsize(800, 680)

        self.last_ciphertext_bytes = b""

        main_frame = ttk.Frame(root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            main_frame,
            text="Лабораторна робота № 5: Дослідження потокового шифрування на базі LFSR\n"
                 "C_i = P_i ⊕ K_i  |  Регістри m=5 (T=31) та m=16 (T=65535)  |  Crib Dragging",
            font=("Segoe UI", 11, "bold"),
            justify=tk.CENTER
        ).pack(pady=(0, 6))

        # 1. Текст
        tg = ttk.LabelFrame(main_frame, text=" 1. Відкритий текст для шифрування ", padding=6)
        tg.pack(fill=tk.BOTH, expand=False, pady=3)
        self.text_input = scrolledtext.ScrolledText(tg, height=3, font=("Segoe UI", 10), wrap=tk.WORD)
        self.text_input.pack(fill=tk.BOTH, expand=True)
        self.text_input.insert(tk.END, DEFAULT_TEXT_1)

        # 2. Налаштування LFSR
        kg = ttk.LabelFrame(main_frame, text=" 2. Налаштування генератора гами (LFSR) ", padding=6)
        kg.pack(fill=tk.X, pady=3)

        row1 = ttk.Frame(kg)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="Режим регістра:").pack(side=tk.LEFT, padx=4)
        self.mode_var = tk.StringVar(value="16")
        ttk.Radiobutton(row1, text="Режим 1: m = 5 біт (період 31)", variable=self.mode_var, value="5").pack(side=tk.LEFT, padx=6)
        ttk.Radiobutton(row1, text="Режим 2: m = 16 біт (період 65535)", variable=self.mode_var, value="16").pack(side=tk.LEFT, padx=6)

        row2 = ttk.Frame(kg)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Початковий стан (Seed / HEX):").pack(side=tk.LEFT, padx=4)
        self.seed_entry = ttk.Entry(row2, width=12)
        self.seed_entry.insert(0, "0xACE1")
        self.seed_entry.pack(side=tk.LEFT, padx=4)

        ttk.Label(row2, text="Crib (слово >= 8 байт):").pack(side=tk.LEFT, padx=(15, 4))
        self.crib_entry = ttk.Entry(row2, width=16)
        self.crib_entry.insert(0, DEFAULT_CRIB)
        self.crib_entry.pack(side=tk.LEFT, padx=4)

        # G2. Поле шифротексту (HEX)
        cg = ttk.LabelFrame(main_frame, text=" 3. Шифротекст (HEX) ", padding=6)
        cg.pack(fill=tk.BOTH, expand=False, pady=3)
        self.cipher_input = scrolledtext.ScrolledText(cg, height=3, font=("Consolas", 9), wrap=tk.WORD)
        self.cipher_input.pack(fill=tk.BOTH, expand=True)

        # 3. Кнопки
        bg = ttk.Frame(main_frame)
        bg.pack(fill=tk.X, pady=4)
        ttk.Button(bg, text="⏱ Перевірити період", command=self.handle_check_period).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🔒 Зашифрувати", command=self.handle_encrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🔓 Дешифрувати (HEX)", command=self.handle_decrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="⚠️ Two-Time Pad", command=self.handle_two_time_pad).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🎯 Crib Dragging", command=self.handle_crib_dragging).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="▶ Авто-демо", command=self.handle_auto_demo).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        # 4. Вивід
        og = ttk.LabelFrame(main_frame, text=" 4. Протокол роботи LFSR та аналіз вразливостей ", padding=6)
        og.pack(fill=tk.BOTH, expand=True, pady=3)
        self.text_output = scrolledtext.ScrolledText(og, font=("Consolas", 9), wrap=tk.WORD, bg="#F9F9F9")
        self.text_output.pack(fill=tk.BOTH, expand=True)

        self.log("Програма готова. Оберіть дію або натисніть «▶ Авто-демо».\n")

    def log(self, msg: str):
        self.text_output.insert(tk.END, msg + "\n")
        self.text_output.see(tk.END)

    def clear_output(self):
        self.text_output.delete("1.0", tk.END)

    def get_lfsr(self):
        try:
            s_val = int(self.seed_entry.get().strip(), 0)
        except ValueError:
            s_val = DEFAULT_SEED_16
        if self.mode_var.get() == "5":
            return create_lfsr_m5(seed=s_val if s_val < 32 else DEFAULT_SEED_5)
        else:
            return create_lfsr_m16(seed=s_val)

    def handle_check_period(self):
        lfsr = self.get_lfsr()
        self.log("=" * 72)
        self.log(f"ЕМПІРИЧНЕ ВИМІРЮВАННЯ ПЕРІОДУ ДЛЯ РЕГІСТРА m = {lfsr.size} біт...")
        t0 = time.perf_counter()
        p = measure_lfsr_period(lfsr)
        dt = time.perf_counter() - t0
        expected = (1 << lfsr.size) - 1
        self.log(f"  • Фактично заміряний період: {p} тактів (час: {dt*1000:.3f} мс)")
        self.log(f"  • Теоретичний період 2^m - 1: {expected}")
        if p == expected:
            self.log("  ✔ ПІДТВЕРДЖЕНО: Регістр генерує М-послідовність максимального періоду!")
        self.log("=" * 72)

    def handle_encrypt(self):
        t = self.text_input.get("1.0", tk.END).strip()
        if not t:
            messagebox.showwarning("Помилка", "Введіть відкритий текст!")
            return
        lfsr = self.get_lfsr()
        ct, gamma = encrypt_stream(t, lfsr)
        self.last_ciphertext_bytes = ct
        hex_ct = ct.hex()

        self.cipher_input.delete("1.0", tk.END)
        self.cipher_input.insert(tk.END, hex_ct)

        self.log("=" * 72)
        self.log(f"🔒 ПОТОКОВЕ ШИФРУВАННЯ UTF-8 (XOR, {len(ct)} байтів):")
        self.log(f"Шифротекст (HEX):\n{hex_ct}")
        self.log(f"Гама шифрування (перші 32 байти HEX): {gamma[:32].hex()}...")
        self.log("Шифротекст розміщено у полі введення HEX.")
        self.log("=" * 72)

    def handle_decrypt(self):
        raw_hex = self.cipher_input.get("1.0", tk.END).strip()
        if not raw_hex:
            if self.last_ciphertext_bytes:
                ct_bytes = self.last_ciphertext_bytes
            else:
                messagebox.showwarning("Помилка", "Поле шифротексту (HEX) порожнє!")
                return
        else:
            try:
                ct_bytes = bytes.fromhex(raw_hex.replace(" ", ""))
            except ValueError:
                messagebox.showerror("Помилка", "Некоректний HEX-формат у полі шифротексту!")
                return

        lfsr = self.get_lfsr()
        p = decrypt_stream(ct_bytes, lfsr)
        self.log("=" * 72)
        self.log(f"🔓 ДЕШИФРУВАННЯ ПОТОКОВОГО ШИФРОТЕКСТУ (довжина: {len(ct_bytes)} байт):")
        self.log(f"Відновлений відкритий текст:\n{p}")
        self.log("=" * 72)

    def handle_two_time_pad(self):
        lfsr = self.get_lfsr()
        c1, _ = encrypt_stream(DEFAULT_TEXT_1, lfsr)
        c2, _ = encrypt_stream(DEFAULT_TEXT_2, lfsr)
        p1_b = DEFAULT_TEXT_1.encode("utf-8")
        p2_b = DEFAULT_TEXT_2.encode("utf-8")
        c1_xor_c2 = xor_bytes(c1, c2)
        p1_xor_p2 = xor_bytes(p1_b, p2_b)
        self.log("=" * 72)
        self.log("ДОСЛІДЖЕННЯ: ПОВТОРНЕ ВИКОРИСТАННЯ ГАМИ (TWO-TIME PAD):")
        self.log(f"Текст 1: «{DEFAULT_TEXT_1[:45]}...»")
        self.log(f"Текст 2: «{DEFAULT_TEXT_2[:45]}...»")
        self.log(f"Рівність C1 ⊕ C2 == P1 ⊕ P2 : {c1_xor_c2 == p1_xor_p2}")
        self.log("✔ Гама K повністю зникла! Отримано чистий XOR відкритих текстів.")
        self.log("=" * 72)

    def handle_crib_dragging(self):
        lfsr = self.get_lfsr()
        c1, _ = encrypt_stream(DEFAULT_TEXT_1, lfsr)
        c2, _ = encrypt_stream(DEFAULT_TEXT_2, lfsr)
        c1_xor_c2 = xor_bytes(c1, c2)
        crib = self.crib_entry.get().strip() or DEFAULT_CRIB

        top_cand = perform_crib_dragging(c1_xor_c2, crib)
        real_pos = DEFAULT_TEXT_1.encode("utf-8").find(crib.encode("utf-8"))

        self.log("=" * 72)
        self.log(f"🎯 СЛІПА АТАКА CRIB DRAGGING ДЛЯ ВІДОМОГО СЛОВА «{crib}»:")
        self.log(f"{'Ранг':<5} | {'Зсув':<6} | {'Частота':<10} | {'Розшифрований фрагмент P2'}")
        self.log("-" * 72)
        for idx, c_item in enumerate(top_cand, 1):
            self.log(f"#{idx:<4} | {c_item['offset']:<6} | {c_item['score']:<10.1%} | «{c_item['text']}»")
        self.log("-" * 72)
        self.log(f"[Пост-перевірка для звіту]: Справжній зсув слова «{crib}» у P1: байт {real_pos}")
        self.log("=" * 72)

    def handle_auto_demo(self):
        self.clear_output()
        self.log("▶ Запуск автоматичної демонстрації ЛР № 5...")
        self.handle_check_period()
        self.handle_encrypt()
        self.handle_two_time_pad()
        self.handle_crib_dragging()


def launch_gui():
    if not HAS_TKINTER:
        print("Графічний інтерфейс Tkinter недоступний у цьому середовищі.")
        print("Використовуйте режим автоматичної демонстрації: python crypto_labs/lab5_stream_lfsr.py --demo")
        return
    root = tk.Tk()
    app = LFSRGUI(root)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("--demo", "-d", "demo"):
        sys.stdout.reconfigure(encoding="utf-8")
        run_auto_demo()
    else:
        launch_gui()
