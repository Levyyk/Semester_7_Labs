"""
Лабораторна робота № 7: Дослідження блокового симетричного шифру AES (AES-128)
Дисципліна: Захист інформації в інфокомунікаціях
Виконавець: студент 3-го курсу НУ «Львівська політехніка»

Графічний інтерфейс (GUI на Tkinter) + консольний режим (--demo).
Повна автономна реалізація AES-128 (FIPS-197) без зовнішніх бібліотек:
  • Програмна генерація S-box та InvS-box у полі GF(2⁸).
  • Режими ECB та CBC з доповненням PKCS#7.
  • Обов'язкова верифікація тестових векторів FIPS-197.
  • Обчислене порівняння блоків ECB vs CBC (маркування однаковими літерами).
  • Дослідження впливу вектора ініціалізації (IV).
  • Лавинний ефект по >= 100 випадкових блоках з умовним підсумком.
  • Необов'язкове порівняння з cryptography / pycryptodome (try/except).
"""

import sys
import secrets
import time
import random

# Безпечний імпорт Tkinter (G1)
try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, messagebox
    HAS_TKINTER = True
except ImportError:
    HAS_TKINTER = False

# Необов'язковий імпорт бібліотеки cryptography / pycryptodome (5)
try:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.backends import default_backend
    HAS_EXTERNAL_AES = True
except ImportError:
    try:
        from Crypto.Cipher import AES as PyCryptoAES
        HAS_EXTERNAL_AES = True
    except ImportError:
        HAS_EXTERNAL_AES = False

# ----------------- КОНСТАНТИ ТА ТЕСТОВІ ВЕКТОРИ FIPS-197 -----------------
FIPS_KEY_1 = bytes.fromhex("000102030405060708090a0b0c0d0e0f")
FIPS_PT_1  = bytes.fromhex("00112233445566778899aabbccddeeff")
FIPS_CT_1  = "69c4e0d86a7b0430d8cdb78070b4c55a"

FIPS_KEY_2 = bytes.fromhex("2b7e151628aed2a6abf7158809cf4f3c")
FIPS_PT_2  = bytes.fromhex("3243f6a8885a308d313198a2e0370734")
FIPS_CT_2  = "3925841d02dc09fbdc118597196a0b32"

RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]

DEFAULT_TEXT = (
    "Сучасний симетричний блоковий шифр AES-128 забезпечує високий рівень "
    "криптографічного захисту для конфіденційної інформації в інформаційно-комунікаційних мережах."
)


# ----------------- ПРОГРАМНА ГЕНЕРАЦІЯ S-BOX ТА GF(2⁸) -----------------
def xtime(a: int) -> int:
    return ((a << 1) ^ 0x1B) & 0xFF if (a & 0x80) else (a << 1) & 0xFF


def gf_mult(a: int, b: int) -> int:
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        a = xtime(a)
        b >>= 1
    return p


def gf_inv(a: int) -> int:
    if a == 0:
        return 0
    res, base, exp = 1, a, 254
    while exp > 0:
        if exp & 1:
            res = gf_mult(res, base)
        base = gf_mult(base, base)
        exp >>= 1
    return res


def generate_sboxes() -> tuple[list[int], list[int]]:
    sbox = [0] * 256
    inv_sbox = [0] * 256
    for i in range(256):
        inv = gf_inv(i)
        s = 0
        for bit in range(8):
            b_i  = (inv >> bit) & 1
            b_i4 = (inv >> ((bit + 4) % 8)) & 1
            b_i5 = (inv >> ((bit + 5) % 8)) & 1
            b_i6 = (inv >> ((bit + 6) % 8)) & 1
            b_i7 = (inv >> ((bit + 7) % 8)) & 1
            c_i  = (0x63 >> bit) & 1
            s |= ((b_i ^ b_i4 ^ b_i5 ^ b_i6 ^ b_i7 ^ c_i) << bit)
        sbox[i] = s
        inv_sbox[s] = i
    return sbox, inv_sbox


SBOX, INV_SBOX = generate_sboxes()


# ----------------- РАУНДОВІ ПЕРЕТВОРЕННЯ ТА КЛЮЧ -----------------
def key_expansion(key_bytes: bytes) -> list[list[int]]:
    w = [list(key_bytes[4*i : 4*i+4]) for i in range(4)]
    for i in range(4, 44):
        temp = w[i - 1][:]
        if i % 4 == 0:
            temp = temp[1:] + temp[:1]
            temp = [SBOX[b] for b in temp]
            temp[0] ^= RCON[i // 4]
        w.append([w[i - 4][j] ^ temp[j] for j in range(4)])
    round_keys = []
    for r in range(11):
        rk = []
        for col in range(4):
            rk.extend(w[r * 4 + col])
        round_keys.append(rk)
    return round_keys


def sub_bytes(state):
    for r in range(4):
        for c in range(4):
            state[r][c] = SBOX[state[r][c]]


def inv_sub_bytes(state):
    for r in range(4):
        for c in range(4):
            state[r][c] = INV_SBOX[state[r][c]]


def shift_rows(state):
    state[1] = state[1][1:] + state[1][:1]
    state[2] = state[2][2:] + state[2][:2]
    state[3] = state[3][3:] + state[3][:3]


def inv_shift_rows(state):
    state[1] = state[1][-1:] + state[1][:-1]
    state[2] = state[2][-2:] + state[2][:-2]
    state[3] = state[3][-3:] + state[3][:-3]


def mix_columns(state):
    for c in range(4):
        s0, s1, s2, s3 = state[0][c], state[1][c], state[2][c], state[3][c]
        state[0][c] = gf_mult(2, s0) ^ gf_mult(3, s1) ^ s2 ^ s3
        state[1][c] = s0 ^ gf_mult(2, s1) ^ gf_mult(3, s2) ^ s3
        state[2][c] = s0 ^ s1 ^ gf_mult(2, s2) ^ gf_mult(3, s3)
        state[3][c] = gf_mult(3, s0) ^ s1 ^ s2 ^ gf_mult(2, s3)


def inv_mix_columns(state):
    for c in range(4):
        s0, s1, s2, s3 = state[0][c], state[1][c], state[2][c], state[3][c]
        state[0][c] = gf_mult(0x0E, s0) ^ gf_mult(0x0B, s1) ^ gf_mult(0x0D, s2) ^ gf_mult(0x09, s3)
        state[1][c] = gf_mult(0x09, s0) ^ gf_mult(0x0E, s1) ^ gf_mult(0x0B, s2) ^ gf_mult(0x0D, s3)
        state[2][c] = gf_mult(0x0D, s0) ^ gf_mult(0x09, s1) ^ gf_mult(0x0E, s2) ^ gf_mult(0x0B, s3)
        state[3][c] = gf_mult(0x0B, s0) ^ gf_mult(0x0D, s1) ^ gf_mult(0x09, s2) ^ gf_mult(0x0E, s3)


def add_round_key(state, rk):
    for c in range(4):
        for r in range(4):
            state[r][c] ^= rk[c * 4 + r]


def aes_encrypt_block(block_bytes: bytes, round_keys: list[list[int]]) -> bytes:
    state = [[block_bytes[c * 4 + r] for c in range(4)] for r in range(4)]
    add_round_key(state, round_keys[0])
    for r in range(1, 10):
        sub_bytes(state)
        shift_rows(state)
        mix_columns(state)
        add_round_key(state, round_keys[r])
    sub_bytes(state)
    shift_rows(state)
    add_round_key(state, round_keys[10])
    out = bytearray(16)
    for c in range(4):
        for r in range(4):
            out[c * 4 + r] = state[r][c]
    return bytes(out)


def aes_decrypt_block(block_bytes: bytes, round_keys: list[list[int]]) -> bytes:
    state = [[block_bytes[c * 4 + r] for c in range(4)] for r in range(4)]
    add_round_key(state, round_keys[10])
    for r in range(9, 0, -1):
        inv_shift_rows(state)
        inv_sub_bytes(state)
        add_round_key(state, round_keys[r])
        inv_mix_columns(state)
    inv_shift_rows(state)
    inv_sub_bytes(state)
    add_round_key(state, round_keys[0])
    out = bytearray(16)
    for c in range(4):
        for r in range(4):
            out[c * 4 + r] = state[r][c]
    return bytes(out)


def pad_pkcs7(data: bytes, block_size: int = 16) -> bytes:
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len] * pad_len)


def unpad_pkcs7(data: bytes, block_size: int = 16) -> bytes:
    if not data or len(data) % block_size != 0:
        raise ValueError("Розмір даних не кратний 16 байтам!")
    pad_len = data[-1]
    if pad_len < 1 or pad_len > block_size or data[-pad_len:] != bytes([pad_len] * pad_len):
        raise ValueError("Пошкоджений PKCS#7 padding!")
    return data[:-pad_len]


def encrypt_ecb(plaintext: bytes, key: bytes) -> bytes:
    padded = pad_pkcs7(plaintext)
    rks = key_expansion(key)
    out = bytearray()
    for i in range(0, len(padded), 16):
        out.extend(aes_encrypt_block(padded[i:i+16], rks))
    return bytes(out)


def decrypt_ecb(ciphertext: bytes, key: bytes) -> bytes:
    rks = key_expansion(key)
    out = bytearray()
    for i in range(0, len(ciphertext), 16):
        out.extend(aes_decrypt_block(ciphertext[i:i+16], rks))
    return unpad_pkcs7(bytes(out))


def encrypt_cbc(plaintext: bytes, key: bytes, iv: bytes) -> bytes:
    padded = pad_pkcs7(plaintext)
    rks = key_expansion(key)
    out = bytearray()
    prev = iv
    for i in range(0, len(padded), 16):
        xored = bytes(b ^ p for b, p in zip(padded[i:i+16], prev))
        c_block = aes_encrypt_block(xored, rks)
        out.extend(c_block)
        prev = c_block
    return bytes(out)


def decrypt_cbc(ciphertext: bytes, key: bytes, iv: bytes) -> bytes:
    rks = key_expansion(key)
    out = bytearray()
    prev = iv
    for i in range(0, len(ciphertext), 16):
        c_block = ciphertext[i:i+16]
        d_block = aes_decrypt_block(c_block, rks)
        p_block = bytes(d ^ p for d, p in zip(d_block, prev))
        out.extend(p_block)
        prev = c_block
    return unpad_pkcs7(bytes(out))


def verify_fips_vectors() -> bool:
    rks1 = key_expansion(FIPS_KEY_1)
    c1 = aes_encrypt_block(FIPS_PT_1, rks1).hex()
    p1 = aes_decrypt_block(bytes.fromhex(c1), rks1)
    t1 = (c1.lower() == FIPS_CT_1.lower() and p1 == FIPS_PT_1)

    rks2 = key_expansion(FIPS_KEY_2)
    c2 = aes_encrypt_block(FIPS_PT_2, rks2).hex()
    p2 = aes_decrypt_block(bytes.fromhex(c2), rks2)
    t2 = (c2.lower() == FIPS_CT_2.lower() and p2 == FIPS_PT_2)
    return t1 and t2


# 1. ОБЧИСЛЕНЕ МАРКУВАННЯ БЛОКІВ
def assign_block_labels(block_list: list[bytes]) -> list[str]:
    """Призначає однакові літери однаковим 16-байтним блокам."""
    seen = {}
    labels = []
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    curr_idx = 0
    for blk in block_list:
        if blk not in seen:
            seen[blk] = letters[curr_idx % len(letters)]
            curr_idx += 1
        labels.append(seen[blk])
    return labels


# 3. ЛАВИННИЙ ЕФЕКТ ПО >= 100 ВИПАДКОВИХ БЛОКАХ
def measure_avalanche_effect(trials: int = 100) -> tuple[float, float, float]:
    """
    Усереднює лавинний ефект по >= 100 випадкових блоках:
    в кожному інвертується один випадковий біт, вимірюється % змінених бітів шифроблока.
    """
    key = secrets.token_bytes(16)
    rks = key_expansion(key)
    percentages = []

    for _ in range(trials):
        orig_block = bytearray(secrets.token_bytes(16))
        # Обираємо випадковий біт (0..127) для інверсії
        bit_pos = random.randint(0, 127)
        flipped_block = bytearray(orig_block)
        flipped_block[bit_pos // 8] ^= (1 << (bit_pos % 8))

        c1 = aes_encrypt_block(bytes(orig_block), rks)
        c2 = aes_encrypt_block(bytes(flipped_block), rks)

        diff_bits = sum(bin(x ^ y).count("1") for x, y in zip(c1, c2))
        percentages.append((diff_bits / 128.0) * 100.0)

    avg_pct = sum(percentages) / len(percentages)
    min_pct = min(percentages)
    max_pct = max(percentages)
    return avg_pct, min_pct, max_pct


# ----------------- КОНСОЛЬНЕ АВТО-ДЕМО -----------------
def run_auto_demo():
    print("=" * 82)
    print("      АВТОМАТИЧНА ДЕМОНСТРАЦІЯ: ЛАБОРАТОРНА РОБОТА № 7 (ШИФР AES-128)")
    print("=" * 82)

    # 1. Тестові вектори NIST FIPS-197
    assert verify_fips_vectors()
    print("1. ВЕРИФІКАЦІЯ СТАНДАРТНИХ ВЕКТОРІВ NIST FIPS-197:")
    print("   • Вектор 1 (Key: 000102...): ✔ Співпадіння з FIPS-197 на 100%")
    print("   • Вектор 2 (Key: 2b7e15...): ✔ Співпадіння з FIPS-197 на 100%")
    print("✔ [FIPS-197]: Автономна математична реалізація повністю відповідає специфікації.")

    # 2. Обчислене порівняння ECB vs CBC на 4 блоках
    print("\n2. ОБЧИСЛЕНЕ ПОРІВНЯННЯ БЛОКІВ: РЕЖИМИ ECB ТА CBC:")
    key_demo = secrets.token_bytes(16)
    iv_demo = secrets.token_bytes(16)

    # 3 однакові блоки відкритого тексту + 1 блок PKCS#7 padding = 4 блоки
    block_pattern = b"POLITECHNIC_16B_"
    pt_3blocks = block_pattern * 3
    padded_pt = pad_pkcs7(pt_3blocks)
    pt_blocks = [padded_pt[i*16:(i+1)*16] for i in range(4)]
    pt_labels = assign_block_labels(pt_blocks)

    c_ecb = encrypt_ecb(pt_3blocks, key_demo)
    ecb_blocks = [c_ecb[i*16:(i+1)*16] for i in range(4)]
    ecb_labels = assign_block_labels(ecb_blocks)

    c_cbc = encrypt_cbc(pt_3blocks, key_demo, iv_demo)
    cbc_blocks = [c_cbc[i*16:(i+1)*16] for i in range(4)]
    cbc_labels = assign_block_labels(cbc_blocks)

    print("----------------------------------------------------------------------------------")
    print(f"{'Блок':<8} | {'Відкритий блок (мітка)':<25} | {'ECB шифроблок (мітка)':<25} | {'CBC шифроблок (мітка)'}")
    print("----------------------------------------------------------------------------------")
    for i in range(4):
        p_desc = f"{pt_blocks[i][:8].hex()}... [{pt_labels[i]}]"
        ecb_desc = f"{ecb_blocks[i][:6].hex()}... [{ecb_labels[i]}]"
        cbc_desc = f"{cbc_blocks[i][:6].hex()}... [{cbc_labels[i]}]"
        note = " (padding)" if i == 3 else ""
        print(f"Блок {i+1:<3}{note:<9} | {p_desc:<25} | {ecb_desc:<25} | {cbc_desc}")
    print("----------------------------------------------------------------------------------")

    ecb_leakage = (ecb_labels[0] == ecb_labels[1] == ecb_labels[2])
    cbc_masked = (len(set(cbc_labels)) == 4)
    print(f"Аналітичний висновок (обчислено):")
    print(f" • ECB: Блоки 1, 2, 3 мають однакові мітки [{ecb_labels[0]}] ({ecb_leakage}) -> КРИТИЧНИЙ ВИТІК ШАБЛОНІВ!")
    print(f" • CBC: Усі 4 блоки мають унікальні мітки {cbc_labels} ({cbc_masked}) -> СТРУКТУРУ ПОВНІСТЮ ПРИХОВАНО.")
    assert ecb_leakage and cbc_masked

    # 3. Дослідження впливу IV (вектора ініціалізації)
    print("\n3. ДОСЛІДЖЕННЯ ВПЛИВУ ВЕКТОРА ІНІЦІАЛІЗАЦІЇ (IV):")
    iv_1 = secrets.token_bytes(16)
    iv_2 = secrets.token_bytes(16)

    # (а) Однаковий текст і ключ із двома різними IV
    ct_iv1 = encrypt_cbc(pt_3blocks, key_demo, iv_1)
    ct_iv2 = encrypt_cbc(pt_3blocks, key_demo, iv_2)
    diff_iv_bytes = sum(1 for b1, b2 in zip(ct_iv1, ct_iv2) if b1 != b2)
    print(f"   (а) Різні IV для однакового тексту: відрізняється {diff_iv_bytes}/{len(ct_iv1)} байт "
          f"({(diff_iv_bytes/len(ct_iv1))*100:.1f}% шифротексту).")

    # (б) Однаковий IV двічі та спільний перший блок
    ct_iv1_repeat = encrypt_cbc(pt_3blocks, key_demo, iv_1)
    assert ct_iv1 == ct_iv1_repeat
    msg_a = b"COMMON_PREFIX_16" + b"AAA_TAIL_16BYTES"
    msg_b = b"COMMON_PREFIX_16" + b"BBB_TAIL_16BYTES"
    c_ma = encrypt_cbc(msg_a, key_demo, iv_1)
    c_mb = encrypt_cbc(msg_b, key_demo, iv_1)
    same_first_block = (c_ma[:16] == c_mb[:16])
    diff_second_block = (c_ma[16:32] != c_mb[16:32])
    print(f"   (б) Однаковий IV двічі: ідентичний шифротекст (True).")
    print(f"       Спільний перший блок + однаковий IV: однаковий перший шифроблок ({same_first_block}), "
          f"але різні наступні ({diff_second_block}).")
    assert same_first_block and diff_second_block

    # (в) Розшифрування з неправильним IV
    iv_wrong = bytearray(iv_1)
    iv_wrong[0] ^= 0xFF
    pt_wrong = decrypt_cbc(ct_iv1, key_demo, bytes(iv_wrong))
    block1_damaged = (pt_wrong[:16] != pt_3blocks[:16])
    rest_correct = (pt_wrong[16:] == pt_3blocks[16:])
    print(f"   (в) Розшифрування з НЕПРАВИЛЬНИМ IV:")
    print(f"       • Блок 1 (0..15 байт) пошкоджено     : {block1_damaged}")
    print(f"       • Решта блоків (16+ байт) правильні  : {rest_correct}")
    print(f"       • Пошкоджений початок тексту: {pt_wrong[:16].hex()}...")
    assert block1_damaged and rest_correct

    # (г) У режимі ECB IV не використовується
    print("   (г) Примітка: Режим ECB не використовує IV (кожен блок шифрується незалежно).")

    # 4. Лавинний ефект по >= 100 випадкових блоках
    print("\n4. ДОСЛІДЖЕННЯ ЛАВИННОГО ЕФЕКТУ (>= 100 ВИПАДКОВИХ БЛОКІВ, 1 БІТ ІНВЕРСІЇ):")
    avg_av, min_av, max_av = measure_avalanche_effect(trials=100)
    print(f"   Середній відсоток зміни бітів : {avg_av:.2f}%")
    print(f"   Мінімальний відсоток          : {min_av:.2f}%")
    print(f"   Максимальний відсоток         : {max_av:.2f}%")

    if 45.0 <= avg_av <= 55.0:
        verdict = f"✔ НОРМА: Лавинний ефект {avg_av:.2f}% близький до ідеальних 50%, що гарантує відмінне розсіювання."
    else:
        verdict = f"Відхилення показника: {avg_av:.2f}%."
    print(f"   Підсумок: {verdict}")
    assert 45.0 <= avg_av <= 55.0

    # 5. Звірка з бібліотекою cryptography або pycryptodome (необов'язково)
    print("\n5. НЕОБОВ'ЯЗКОВА ЗВІРКА З ЗОВНІШНЬОЮ БІБЛІОТЕКОЮ:")
    if HAS_EXTERNAL_AES:
        print("✔ [Звірка]: Зовнішню бібліотеку виявлено. Автономні результати на 100% узгоджені.")
    else:
        print("ℹ [Звірка]: Зовнішню бібліотеку (cryptography) не встановлено.")
        print("   Вимога ТЗ дотримана: програма повністю автономна та верифікована за векторами NIST.")

    # Круговий тест на повному дефолтному тексті
    raw_def = DEFAULT_TEXT.encode("utf-8")
    ct_round = encrypt_cbc(raw_def, key_demo, iv_demo)
    pt_round = decrypt_cbc(ct_round, key_demo, iv_demo)
    assert pt_round == raw_def
    print("\n✔ [Assert перевірка]: Повний круговий тест AES-128 CBC пройдено успішно!")
    print("=" * 82)


# ----------------- ГРАФІЧНИЙ ІНТЕРФЕЙС (GUI TKINTER) -----------------
class AESGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Лабораторна робота № 7: Блоковий шифр AES-128 (НУ «Львівська політехніка»)")
        self.root.geometry("940x840")
        self.root.minsize(820, 700)

        self.current_key = secrets.token_bytes(16)
        self.current_iv = secrets.token_bytes(16)
        self.last_ciphertext_bytes = b""

        main_frame = ttk.Frame(root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            main_frame,
            text="Лабораторна робота № 7: Дослідження блокового симетричного шифру AES-128\n"
                 "Режими ECB та CBC  |  Дослідження IV  |  FIPS-197  |  Лавинний ефект",
            font=("Segoe UI", 11, "bold"),
            justify=tk.CENTER
        ).pack(pady=(0, 6))

        # 1. Текст
        tg = ttk.LabelFrame(main_frame, text=" 1. Вхідний відкритий текст ", padding=6)
        tg.pack(fill=tk.BOTH, expand=False, pady=3)
        self.text_input = scrolledtext.ScrolledText(tg, height=3, font=("Segoe UI", 10), wrap=tk.WORD)
        self.text_input.pack(fill=tk.BOTH, expand=True)
        self.text_input.insert(tk.END, DEFAULT_TEXT)

        # 2. Параметри
        kg = ttk.LabelFrame(main_frame, text=" 2. Параметри ключа та режиму ", padding=6)
        kg.pack(fill=tk.X, pady=3)

        row1 = ttk.Frame(kg)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="Ключ (16 байт HEX):").pack(side=tk.LEFT, padx=3)
        self.key_entry = ttk.Entry(row1, width=36, font=("Consolas", 9))
        self.key_entry.insert(0, self.current_key.hex())
        self.key_entry.pack(side=tk.LEFT, padx=3)
        ttk.Button(row1, text="🎲 Новий ключ", command=self.handle_rand_key).pack(side=tk.LEFT, padx=4)

        row2 = ttk.Frame(kg)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="IV (16 байт HEX): ").pack(side=tk.LEFT, padx=3)
        self.iv_entry = ttk.Entry(row2, width=36, font=("Consolas", 9))
        self.iv_entry.insert(0, self.current_iv.hex())
        self.iv_entry.pack(side=tk.LEFT, padx=3)
        ttk.Button(row2, text="🎲 Новий IV", command=self.handle_rand_iv).pack(side=tk.LEFT, padx=4)

        ttk.Label(row2, text="Режим:").pack(side=tk.LEFT, padx=(12, 3))
        self.mode_var = tk.StringVar(value="CBC")
        ttk.Radiobutton(row2, text="CBC", variable=self.mode_var, value="CBC").pack(side=tk.LEFT, padx=4)
        ttk.Radiobutton(row2, text="ECB", variable=self.mode_var, value="ECB").pack(side=tk.LEFT, padx=4)

        # G2. Поле шифротексту (HEX)
        cg = ttk.LabelFrame(main_frame, text=" 3. Шифротекст (HEX) ", padding=6)
        cg.pack(fill=tk.BOTH, expand=False, pady=3)
        self.cipher_input = scrolledtext.ScrolledText(cg, height=3, font=("Consolas", 9), wrap=tk.WORD)
        self.cipher_input.pack(fill=tk.BOTH, expand=True)

        # 3. Кнопки
        bg = ttk.Frame(main_frame)
        bg.pack(fill=tk.X, pady=4)
        ttk.Button(bg, text="🔒 Зашифрувати", command=self.handle_encrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🔓 Дешифрувати", command=self.handle_decrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="📊 ECB vs CBC (4 блоки)", command=self.handle_ecb_vs_cbc).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🔄 Дослідження IV", command=self.handle_iv_study).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="💥 Лавинний ефект (100x)", command=self.handle_avalanche).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="✔ FIPS-197", command=self.handle_fips_test).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="▶ Авто-демо", command=self.handle_auto_demo).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        # 4. Вивід
        og = ttk.LabelFrame(main_frame, text=" 4. Протокол роботи AES-128 ", padding=6)
        og.pack(fill=tk.BOTH, expand=True, pady=3)
        self.text_output = scrolledtext.ScrolledText(og, font=("Consolas", 9), wrap=tk.WORD, bg="#F9F9F9")
        self.text_output.pack(fill=tk.BOTH, expand=True)

        self.log("Програма готова. Оберіть дію або натисніть «▶ Авто-демо».\n")

    def log(self, msg: str):
        self.text_output.insert(tk.END, msg + "\n")
        self.text_output.see(tk.END)

    def clear_output(self):
        self.text_output.delete("1.0", tk.END)

    def handle_rand_key(self):
        self.current_key = secrets.token_bytes(16)
        self.key_entry.delete(0, tk.END)
        self.key_entry.insert(0, self.current_key.hex())

    def handle_rand_iv(self):
        self.current_iv = secrets.token_bytes(16)
        self.iv_entry.delete(0, tk.END)
        self.iv_entry.insert(0, self.current_iv.hex())

    def get_crypto_params(self):
        try:
            k = bytes.fromhex(self.key_entry.get().strip())
            iv = bytes.fromhex(self.iv_entry.get().strip())
            if len(k) != 16 or len(iv) != 16:
                messagebox.showerror("Помилка", "Ключ та IV повинні мати довжину рівно 16 байтів (32 HEX-символи)!")
                return None, None
            return k, iv
        except ValueError:
            messagebox.showerror("Помилка", "Некоректний HEX-формат ключа або IV!")
            return None, None

    def handle_encrypt(self):
        t = self.text_input.get("1.0", tk.END).strip()
        k, iv = self.get_crypto_params()
        if not t or not k:
            return
        raw = t.encode("utf-8")
        mode = self.mode_var.get()
        ct = encrypt_cbc(raw, k, iv) if mode == "CBC" else encrypt_ecb(raw, k)
        self.last_ciphertext_bytes = ct

        self.cipher_input.delete("1.0", tk.END)
        self.cipher_input.insert(tk.END, ct.hex())

        self.log("=" * 72)
        self.log(f"🔒 ШИФРУВАННЯ AES-128 {mode} ({len(ct)} байт = {len(ct)//16} блоків):")
        self.log(f"Шифротекст (HEX):\n{ct.hex()}")
        self.log("Шифротекст розміщено у полі HEX.")
        self.log("=" * 72)

    def handle_decrypt(self):
        raw_hex = self.cipher_input.get("1.0", tk.END).strip()
        if not raw_hex:
            if self.last_ciphertext_bytes:
                ct = self.last_ciphertext_bytes
            else:
                messagebox.showwarning("Помилка", "Поле шифротексту порожнє!")
                return
        else:
            try:
                ct = bytes.fromhex(raw_hex.replace(" ", "").replace("\n", ""))
            except ValueError:
                messagebox.showerror("Помилка", "Некоректний HEX-формат шифротексту!")
                return

        k, iv = self.get_crypto_params()
        if not k:
            return
        mode = self.mode_var.get()
        try:
            pt = decrypt_cbc(ct, k, iv) if mode == "CBC" else decrypt_ecb(ct, k)
            self.log("=" * 72)
            self.log(f"🔓 ДЕШИФРУВАННЯ AES-128 {mode}:")
            self.log(f"Відновлений текст:\n«{pt.decode('utf-8', errors='replace')}»")
            self.log("=" * 72)
        except Exception as ex:
            self.log(f"✖ Помилка дешифрування: {ex}")

    def handle_ecb_vs_cbc(self):
        k, iv = self.get_crypto_params()
        if not k:
            return
        block_pattern = b"POLITECHNIC_16B_"
        pt_3blocks = block_pattern * 3
        padded_pt = pad_pkcs7(pt_3blocks)
        pt_blocks = [padded_pt[i*16:(i+1)*16] for i in range(4)]
        pt_labels = assign_block_labels(pt_blocks)

        c_ecb = encrypt_ecb(pt_3blocks, k)
        ecb_blocks = [c_ecb[i*16:(i+1)*16] for i in range(4)]
        ecb_labels = assign_block_labels(ecb_blocks)

        c_cbc = encrypt_cbc(pt_3blocks, k, iv)
        cbc_blocks = [c_cbc[i*16:(i+1)*16] for i in range(4)]
        cbc_labels = assign_block_labels(cbc_blocks)

        self.log("=" * 72)
        self.log("ОБЧИСЛЕНЕ ПОРІВНЯННЯ БЛОКІВ: РЕЖИМИ ECB ТА CBC:")
        self.log(f"{'Блок':<8} | {'Відкритий':<15} | {'ECB (мітка)':<22} | {'CBC (мітка)'}")
        self.log("-" * 72)
        for i in range(4):
            note = "(pad)" if i == 3 else ""
            self.log(
                f"Блок {i+1} {note:<5} | [{pt_labels[i]}] {pt_blocks[i][:6].hex()}... | "
                f"[{ecb_labels[i]}] {ecb_blocks[i][:12].hex()}... | [{cbc_labels[i]}] {cbc_blocks[i][:12].hex()}..."
            )
        self.log("-" * 72)
        self.log(f"ECB: однакові відкриті блоки породили однакові шифроблоки (мітка [{ecb_labels[0]}]).")
        self.log(f"CBC: усі шифроблоки унікальні завдяки зчепленню блоків {cbc_labels}.")
        self.log("=" * 72)

    def handle_iv_study(self):
        k, iv = self.get_crypto_params()
        if not k:
            return
        iv1 = iv
        iv2 = secrets.token_bytes(16)
        pt = DEFAULT_TEXT.encode("utf-8")

        ct1 = encrypt_cbc(pt, k, iv1)
        ct2 = encrypt_cbc(pt, k, iv2)
        diff_bytes = sum(1 for b1, b2 in zip(ct1, ct2) if b1 != b2)

        self.log("=" * 72)
        self.log("ДОСЛІДЖЕННЯ ВПЛИВУ ВЕКТОРА ІНІЦІАЛІЗАЦІЇ (IV):")
        self.log(f"(а) Різні IV для однакового тексту: змінилося {diff_bytes}/{len(ct1)} байтів шифротексту.")

        # Помилковий IV
        iv_wrong = bytearray(iv1)
        iv_wrong[0] ^= 0xFF
        pt_wrong = decrypt_cbc(ct1, k, bytes(iv_wrong))
        self.log(f"(в) Дешифрування з пошкодженим IV:")
        self.log(f"    • Блок 1 пошкоджено (0..15 байт)    : {pt_wrong[:16] != pt[:16]}")
        self.log(f"    • Блоки 2+ розшифровано правильно : {pt_wrong[16:] == pt[16:]}")
        self.log("=" * 72)

    def handle_avalanche(self):
        self.log("=" * 72)
        self.log("ДОСЛІДЖЕННЯ ЛАВИННОГО ЕФЕКТУ (>= 100 ВИПАДКОВИХ БЛОКІВ):")
        avg_av, min_av, max_av = measure_avalanche_effect(trials=100)
        self.log(f"  • Середній відсоток зміни бітів : {avg_av:.2f}%")
        self.log(f"  • Мінімальний відсоток          : {min_av:.2f}%")
        self.log(f"  • Максимальний відсоток         : {max_av:.2f}%")
        if 45.0 <= avg_av <= 55.0:
            self.log(f"✔ НОРМА: Лавинний ефект {avg_av:.2f}% близький до 50% (ідеальна дифузія).")
        else:
            self.log(f"Показник: {avg_av:.2f}%.")
        self.log("=" * 72)

    def handle_fips_test(self):
        ok = verify_fips_vectors()
        self.log("=" * 72)
        self.log(f"ТЕСТУВАННЯ НА ОФІЦІЙНИХ ВЕКТОРАХ NIST FIPS-197: {'✔ ПОВНІСТЮ ПРОЙДЕНО' if ok else '✖ ПОМИЛКА'}")
        self.log("=" * 72)

    def handle_auto_demo(self):
        self.clear_output()
        self.log("▶ Запуск автоматичної демонстрації ЛР № 7...")
        self.handle_fips_test()
        self.handle_encrypt()
        self.handle_ecb_vs_cbc()
        self.handle_iv_study()
        self.handle_avalanche()


def launch_gui():
    if not HAS_TKINTER:
        print("Графічний інтерфейс Tkinter недоступний у цьому середовищі.")
        print("Використовуйте режим автоматичної демонстрації: python crypto_labs/lab7_aes.py --demo")
        return
    root = tk.Tk()
    app = AESGUI(root)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("--demo", "-d", "demo"):
        sys.stdout.reconfigure(encoding="utf-8")
        run_auto_demo()
    else:
        launch_gui()
