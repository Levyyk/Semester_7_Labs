"""
Лабораторна робота № 6: Дослідження асиметричної криптосистеми з відкритим ключем (RSA)
Дисципліна: Захист інформації в інфокомунікаціях
Виконавець: студент 3-го курсу НУ «Львівська політехніка»

Графічний інтерфейс (GUI на Tkinter) + консольний режим (--demo).
RSA: навчальний режим (n > 1200) та реальний 1024-бітний (Міллер-Рабін).
Шифрування: C = M^e mod n, Дешифрування: M = C^d mod n.
ЕЦП за методичкою: S = M^d mod n, перевірка M = S^e mod n, хеш-підпис SHA-256.
Факторизація модуля для n < 10^12 з вимірюванням часу.
"""

import sys
import time
import secrets
import hashlib
import math

# Безпечний імпорт Tkinter (G1)
try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, messagebox
    HAS_TKINTER = True
except ImportError:
    HAS_TKINTER = False

# ----------------- КОНСТАНТИ ЗА ЗАМОВЧУВАННЯМ -----------------
DEFAULT_P_EDU = 61
DEFAULT_Q_EDU = 53
DEFAULT_E_EDU = 17
DEFAULT_MESSAGE = "Конфіденційне повідомлення кафедри безпеки Львівської політехніки."


# ----------------- БАЗОВІ АЛГОРИТМИ ТА ТЕОРІЯ ЧИСЕЛ -----------------
def gcd(a: int, b: int) -> int:
    while b != 0:
        a, b = b, a % b
    return abs(a)


def extended_gcd(a: int, b: int) -> tuple[int, int, int]:
    if a == 0:
        return b, 0, 1
    gcd_val, x1, y1 = extended_gcd(b % a, a)
    return gcd_val, y1 - (b // a) * x1, x1


def mod_inverse(e: int, phi: int) -> int:
    gcd_val, x, _ = extended_gcd(e, phi)
    if gcd_val != 1:
        raise ValueError(f"Числа e={e} та φ={phi} не є взаємно простими (НСД = {gcd_val})!")
    return (x % phi + phi) % phi


def square_and_multiply(base: int, exponent: int, modulus: int) -> int:
    if modulus == 1:
        return 0
    res = 1
    base = base % modulus
    for bit in bin(exponent)[2:]:
        res = (res * res) % modulus
        if bit == '1':
            res = (res * base) % modulus
    return res


def is_prime_miller_rabin(n: int, rounds: int = 20) -> bool:
    if n < 2:
        return False
    small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]
    if n in small_primes:
        return True
    if any(n % p == 0 for p in small_primes):
        return False

    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1

    for _ in range(rounds):
        a = secrets.randbelow(n - 3) + 2
        x = square_and_multiply(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = square_and_multiply(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def generate_prime(bits: int = 512) -> int:
    while True:
        candidate = secrets.randbits(bits) | (1 << (bits - 1)) | 1
        if is_prime_miller_rabin(candidate):
            return candidate


# 2. ВАЛІДАЦІЯ ПАРАМЕТРІВ RSA
def validate_rsa_parameters(p: int, q: int, e: int, message: str = "") -> None:
    """
    Повна валідація параметрів у навчальному режимі:
    - p і q прості (тест Міллера-Рабіна)
    - p ≠ q
    - gcd(e, φ) = 1
    - n > max(ord(символу)) у повідомленні
    """
    if not is_prime_miller_rabin(p):
        raise ValueError(f"Число p = {p} не є простим!")
    if not is_prime_miller_rabin(q):
        raise ValueError(f"Число q = {q} не є простим!")
    if p == q:
        raise ValueError("Числа p та q мають бути різними!")

    phi = (p - 1) * (q - 1)
    if gcd(e, phi) != 1:
        raise ValueError(f"Експонента e={e} та φ(n)={phi} не є взаємно простими (НСД = {gcd(e, phi)})!")

    n = p * q
    if message:
        max_char = max(ord(ch) for ch in message)
        if n <= max_char:
            raise ValueError(
                f"Модуль n = p * q = {n} занадто малий для посимвольного шифрування! "
                f"Максимальний код символу в тексті: {max_char}. Потрібно n > {max_char}."
            )


class RSAKeyPair:
    def __init__(self, p: int, q: int, e: int = 65537, message: str = ""):
        validate_rsa_parameters(p, q, e, message)
        self.p = p
        self.q = q
        self.n = p * q
        self.phi = (p - 1) * (q - 1)
        self.e = e
        self.d = mod_inverse(self.e, self.phi)

    @property
    def public_key(self):
        return (self.e, self.n)

    @property
    def private_key(self):
        return (self.d, self.n)


# ----------------- ШИФРУВАННЯ ТА ДЕШИФРУВАННЯ -----------------
def encrypt_text_educational(text: str, pub_key: tuple[int, int]) -> list[int]:
    e, n = pub_key
    return [square_and_multiply(ord(ch), e, n) for ch in text]


def decrypt_text_educational(ciphertext: list[int], priv_key: tuple[int, int]) -> str:
    d, n = priv_key
    return "".join(chr(square_and_multiply(c, d, n)) for c in ciphertext)


def encrypt_text_real(text: str, pub_key: tuple[int, int], block_bytes: int = 64) -> list[int]:
    e, n = pub_key
    raw = text.encode("utf-8")
    return [pow(int.from_bytes(raw[i:i+block_bytes], "big"), e, n) for i in range(0, len(raw), block_bytes)]


def decrypt_text_real(blocks: list[int], priv_key: tuple[int, int]) -> str:
    d, n = priv_key
    recovered = bytearray()
    for c_int in blocks:
        m_int = pow(c_int, d, n)
        b_len = max((m_int.bit_length() + 7) // 8, 1)
        recovered.extend(m_int.to_bytes(b_len, "big"))
    return recovered.decode("utf-8", errors="replace")


# 1. ПІДПИС ЗА МЕТОДИЧКОЮ: S = M^d mod n
def sign_direct_educational(text: str, priv_key: tuple[int, int]) -> list[int]:
    """Посимвольний прямий цифровий підпис: S_i = M_i^d mod n."""
    d, n = priv_key
    return [square_and_multiply(ord(ch), d, n) for ch in text]


def verify_direct_educational(text: str, signature: list[int], pub_key: tuple[int, int]) -> bool:
    """Перевірка прямого підпису: M_i = S_i^e mod n."""
    e, n = pub_key
    if len(text) != len(signature):
        return False
    for ch, s_val in zip(text, signature):
        m_rec = square_and_multiply(s_val, e, n)
        if m_rec != ord(ch):
            return False
    return True


def sign_direct_real(text: str, priv_key: tuple[int, int], block_bytes: int = 64) -> list[int]:
    """Блоковий прямий цифровий підпис: S_i = M_i^d mod n."""
    d, n = priv_key
    raw = text.encode("utf-8")
    return [pow(int.from_bytes(raw[i:i+block_bytes], "big"), d, n) for i in range(0, len(raw), block_bytes)]


def verify_direct_real(text: str, signature: list[int], pub_key: tuple[int, int], block_bytes: int = 64) -> bool:
    """Верифікація блокового підпису."""
    e, n = pub_key
    raw = text.encode("utf-8")
    expected_blocks = [int.from_bytes(raw[i:i+block_bytes], "big") for i in range(0, len(raw), block_bytes)]
    if len(expected_blocks) != len(signature):
        return False
    for m_exp, s_val in zip(expected_blocks, signature):
        if pow(s_val, e, n) != m_exp:
            return False
    return True


# ХЕШ-ПІДПИС SHA-256 (ДОДАТКОВИЙ)
def sign_message_hash(text: str, priv_key: tuple[int, int]) -> int:
    d, n = priv_key
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    h_int = int.from_bytes(digest, "big") % n
    return square_and_multiply(h_int, d, n)


def verify_signature_hash(text: str, signature: int, pub_key: tuple[int, int]) -> bool:
    e, n = pub_key
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    expected_h = int.from_bytes(digest, "big") % n
    return square_and_multiply(signature, e, n) == expected_h


# 4. ТЕСТ ФАКТОРИЗАЦІЇ
def factorize_modulus(n: int) -> tuple[int, int, float] | None:
    """
    Факторизація модуля n методом пробного поділу до sqrt(n).
    Працює для n < 10^12 з вимірюванням точного часу.
    """
    if n >= 10**12:
        return None

    t0 = time.perf_counter()
    limit = math.isqrt(n)
    for divisor in range(2, limit + 1):
        if n % divisor == 0:
            dt = time.perf_counter() - t0
            return divisor, n // divisor, dt
    dt = time.perf_counter() - t0
    return n, 1, dt


# ----------------- КОНСОЛЬНЕ АВТО-ДЕМО -----------------
def run_auto_demo():
    print("=" * 82)
    print("      АВТОМАТИЧНА ДЕМОНСТРАЦІЯ: ЛАБОРАТОРНА РОБОТА № 6 (КРИПТОСИСТЕМА RSA)")
    print("=" * 82)

    # 1. Параметри та генерація ключів (навчальний режим)
    keys_edu = RSAKeyPair(DEFAULT_P_EDU, DEFAULT_Q_EDU, DEFAULT_E_EDU, DEFAULT_MESSAGE)
    print("1. ПАРАМЕТРИ КРИПТОСИСТЕМИ RSA (НАВЧАЛЬНИЙ РЕЖИМ):")
    print(f"   Просте число p          : {keys_edu.p}")
    print(f"   Просте число q          : {keys_edu.q}")
    print(f"   Модуль n = p * q        : {keys_edu.n} ({keys_edu.n.bit_length()} біт)")
    print(f"   Функція Ейлера φ(n)     : {keys_edu.phi}")
    print(f"   Відкрита експонента e   : {keys_edu.e}")
    print(f"   Секретна експонента d   : {keys_edu.d}")
    print(f"   Відкритий ключ (e, n)   : ({keys_edu.e}, {keys_edu.n})")
    print(f"   Секретний ключ (d, n)   : ({keys_edu.d}, {keys_edu.n})")
    print("✔ [Валідація ключів]: p, q прості, p ≠ q, gcd(e, φ)=1, n > max(ord(ch)).")

    # 2. Шифрування та дешифрування
    c_edu = encrypt_text_educational(DEFAULT_MESSAGE, keys_edu.public_key)
    p_edu = decrypt_text_educational(c_edu, keys_edu.private_key)
    assert p_edu == DEFAULT_MESSAGE, "Помилка дешифрування RSA!"
    print(f"\n2. ШИФРУВАННЯ ТА ДЕШИФРУВАННЯ RSA:")
    print(f"   Відкритий текст: «{DEFAULT_MESSAGE[:55]}...»")
    print(f"   Шифротекст C (перші 10 чисел): {c_edu[:10]}...")
    print("✔ [Вбудована перевірка]: Дешифрований текст на 100% збігається з оригіналом.")

    # 3. Електронний цифровий підпис за методичкою (S = M^d mod n)
    print("\n3. ЕЛЕКТРОННИЙ ЦИФРОВИЙ ПІДПИС ЗА МЕТОДИЧКОЮ (S = M^d mod n):")
    sig_direct = sign_direct_educational(DEFAULT_MESSAGE, keys_edu.private_key)
    print(f"   Прямий підпис повідомлення (перші 10 значень S_i): {sig_direct[:10]}...")
    valid_direct = verify_direct_educational(DEFAULT_MESSAGE, sig_direct, keys_edu.public_key)
    assert valid_direct, "Помилка верифікації прямого підпису!"
    print(f"   Верифікація справжнього тексту: {'✔ ПІДТВЕРДЖЕНО' if valid_direct else '✖ ПРОВАЛ'}")

    tampered_msg = DEFAULT_MESSAGE + "!"
    tamper_direct = verify_direct_educational(tampered_msg, sig_direct, keys_edu.public_key)
    assert not tamper_direct, "Помилка: підроблений підпис не було відхилено!"
    print(f"   Верифікація підробленого тексту: {'ПРИЙНЯТО' if tamper_direct else '✔ ВІДХИЛЕНО (Цілісність порушено!)'}")

    # 4. Додатковий хеш-підпис SHA-256
    print("\n4. ДОДАТКОВИЙ ПІДПИС ХЕША SHA-256 (S = H(M)^d mod n):")
    sig_hash = sign_message_hash(DEFAULT_MESSAGE, keys_edu.private_key)
    print(f"   Хеш-підпис S: {sig_hash}")
    valid_hash = verify_signature_hash(DEFAULT_MESSAGE, sig_hash, keys_edu.public_key)
    tamper_hash = verify_signature_hash(tampered_msg, sig_hash, keys_edu.public_key)
    assert valid_hash and not tamper_hash
    print(f"   Верифікація справжнього хеша: {'✔ ПІДТВЕРДЖЕНО' if valid_hash else '✖ ПРОВАЛ'}")
    print(f"   Верифікація підробленого хеша: {'ПРИЙНЯТО' if tamper_hash else '✔ ВІДХИЛЕНО'}")

    # 5. Застереження щодо малого n у навчальному режимі
    print("\n5. ЗАСТЕРЕЖЕННЯ ЩОДО БЕЗПЕКИ ХЕШ-ПІДПИСУ У НАВЧАЛЬНОМУ РЕЖИМІ:")
    print("   У навчальному режимі при n = 3233 хеш SHA-256 редукується за малим модулем n (H mod n).")
    print(f"   Це створює ймовірність хибного прийняття підробки приблизно 1/n ≈ 1/{keys_edu.n} ≈ {100/keys_edu.n:.4f}%.")
    print("   У реальних криптосистемах розмір n >= 2048 біт виключає випадкові колізії (1/2^2048 ≈ 0).")

    # 6. Тест факторизації для n < 10^12
    print("\n6. ДОСЛІДЖЕННЯ ФАКТОРИЗАЦІЇ МОДУЛЯ n:")
    print(f"   Атака на навчальний модуль n = {keys_edu.n}...")
    res_fact = factorize_modulus(keys_edu.n)
    if res_fact:
        f1, f2, dt = res_fact
        print(f"   ✔ УСПІШНО ЗЛАМАНО: {keys_edu.n} = {f1} × {f2} за {dt*1000:.3f} мс.")
        assert {f1, f2} == {keys_edu.p, keys_edu.q}

    large_n = 1000000007 * 1000000009  # ~10^18
    print(f"\n   Оцінка стійкості 1024-бітного RSA:")
    print("   1024-бітні модулі вважаються недостатньо стійкими проти потужних зловмисників (актуальний мінімум 2048 біт).")
    print("   Режим 1024 біт використовується лише для навчальної демонстрації.")
    print("=" * 82)


# ----------------- ГРАФІЧНИЙ ІНТЕРФЕЙС (GUI TKINTER) -----------------
class RSAGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Лабораторна робота № 6: Криптосистема RSA (НУ «Львівська політехніка»)")
        self.root.geometry("940x840")
        self.root.minsize(820, 700)

        self.keys = RSAKeyPair(DEFAULT_P_EDU, DEFAULT_Q_EDU, DEFAULT_E_EDU, DEFAULT_MESSAGE)
        self.current_mode = "edu"
        self.last_ciphertext_numbers = []

        main_frame = ttk.Frame(root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            main_frame,
            text="Лабораторна робота № 6: Дослідження асиметричної криптосистеми RSA\n"
                 "Шифрування  |  Підпис за методичкою (S = M^d mod n)  |  SHA-256  |  Факторизація",
            font=("Segoe UI", 11, "bold"),
            justify=tk.CENTER
        ).pack(pady=(0, 6))

        # 1. Повідомлення
        tg = ttk.LabelFrame(main_frame, text=" 1. Текст відкритого повідомлення (M) ", padding=6)
        tg.pack(fill=tk.BOTH, expand=False, pady=3)
        self.text_input = scrolledtext.ScrolledText(tg, height=3, font=("Segoe UI", 10), wrap=tk.WORD)
        self.text_input.pack(fill=tk.BOTH, expand=True)
        self.text_input.insert(tk.END, DEFAULT_MESSAGE)

        # 2. Налаштування параметрів
        kg = ttk.LabelFrame(main_frame, text=" 2. Параметри криптосистеми RSA (p, q, e) ", padding=6)
        kg.pack(fill=tk.X, pady=3)

        row1 = ttk.Frame(kg)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="Режим:").pack(side=tk.LEFT, padx=4)
        self.mode_var = tk.StringVar(value="edu")
        ttk.Radiobutton(row1, text="Навчальний (малі прості p, q)", variable=self.mode_var, value="edu").pack(side=tk.LEFT, padx=6)
        ttk.Radiobutton(row1, text="Реальний (1024-бітний модуль)", variable=self.mode_var, value="real").pack(side=tk.LEFT, padx=6)

        row2 = ttk.Frame(kg)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="p:").pack(side=tk.LEFT, padx=2)
        self.p_entry = ttk.Entry(row2, width=8)
        self.p_entry.insert(0, str(DEFAULT_P_EDU))
        self.p_entry.pack(side=tk.LEFT, padx=3)

        ttk.Label(row2, text="q:").pack(side=tk.LEFT, padx=2)
        self.q_entry = ttk.Entry(row2, width=8)
        self.q_entry.insert(0, str(DEFAULT_Q_EDU))
        self.q_entry.pack(side=tk.LEFT, padx=3)

        ttk.Label(row2, text="e:").pack(side=tk.LEFT, padx=2)
        self.e_entry = ttk.Entry(row2, width=8)
        self.e_entry.insert(0, str(DEFAULT_E_EDU))
        self.e_entry.pack(side=tk.LEFT, padx=3)

        ttk.Button(row2, text="⚙ Розрахувати ключі", command=self.handle_gen_keys).pack(side=tk.LEFT, padx=8)

        self.key_info_var = tk.StringVar(
            value=f"p={self.keys.p}, q={self.keys.q}, n={self.keys.n}, φ={self.keys.phi}, e={self.keys.e}, d={self.keys.d}"
        )
        ttk.Label(kg, textvariable=self.key_info_var, font=("Consolas", 9, "bold"), foreground="#003366").pack(anchor=tk.W, pady=2)

        # G2. Поле шифротексту (числа)
        cg = ttk.LabelFrame(main_frame, text=" 3. Шифротекст (числа через кому або пробіл) ", padding=6)
        cg.pack(fill=tk.BOTH, expand=False, pady=3)
        self.cipher_input = scrolledtext.ScrolledText(cg, height=3, font=("Consolas", 9), wrap=tk.WORD)
        self.cipher_input.pack(fill=tk.BOTH, expand=True)

        # 3. Кнопки дій
        bg = ttk.Frame(main_frame)
        bg.pack(fill=tk.X, pady=4)
        ttk.Button(bg, text="🔒 Зашифрувати", command=self.handle_encrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🔓 Дешифрувати", command=self.handle_decrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="✍ Підпис (S = M^d mod n)", command=self.handle_sign_direct).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🔐 Хеш-підпис (SHA-256)", command=self.handle_sign_hash).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🛑 Тест підробки", command=self.handle_tamper_test).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🔍 Факторизація n", command=self.handle_factorize).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="▶ Авто-демо", command=self.handle_auto_demo).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        # 4. Вивід
        og = ttk.LabelFrame(main_frame, text=" 4. Протокол роботи криптосистеми RSA ", padding=6)
        og.pack(fill=tk.BOTH, expand=True, pady=3)
        self.text_output = scrolledtext.ScrolledText(og, font=("Consolas", 9), wrap=tk.WORD, bg="#F9F9F9")
        self.text_output.pack(fill=tk.BOTH, expand=True)

        self.log("Програма готова. Оберіть режим або натисніть «▶ Авто-демо».\n")

    def log(self, msg: str):
        self.text_output.insert(tk.END, msg + "\n")
        self.text_output.see(tk.END)

    def clear_output(self):
        self.text_output.delete("1.0", tk.END)

    def handle_gen_keys(self):
        if self.mode_var.get() == "real":
            self.log("Генерація 1024-бітних ключів за тестом Міллера-Рабіна...")
            t0 = time.perf_counter()
            try:
                e_val = int(self.e_entry.get().strip() or "65537")
            except ValueError:
                e_val = 65537

            # Для e=65537 перегенеровуємо p і q при невдачі; для власного e перехоплюємо помилку
            success = False
            max_attempts = 10 if e_val == 65537 else 1
            for attempt in range(max_attempts):
                p = generate_prime(512)
                q = generate_prime(512)
                while q == p:
                    q = generate_prime(512)
                try:
                    self.keys = RSAKeyPair(p, q, e=e_val)
                    success = True
                    break
                except ValueError as ve:
                    if e_val == 65537:
                        continue
                    else:
                        if messagebox:
                            messagebox.showerror("Помилка параметрів RSA", f"Неприпустимі параметри (e={e_val}):\n{ve}")
                        self.log(f"✖ Помилка параметрів RSA: {ve}")
                        return

            if not success:
                if messagebox:
                    messagebox.showerror("Помилка генерації", "Не вдалося згенерувати пару ключів для заданого e.")
                self.log("✖ Помилка: не вдалося підібрати сумісні прості числа.")
                return

            dt = time.perf_counter() - t0
            self.current_mode = "real"
            self.key_info_var.set(f"1024-бітний RSA: n={self.keys.n.bit_length()} біт, e={self.keys.e}")
            self.log("=" * 72)
            self.log(f"✔ 1024-бітні демонстраційні ключі згенеровано за {dt:.3f} с:")
            self.log(f"p ({p.bit_length()} біт): {p}")
            self.log(f"q ({q.bit_length()} біт): {q}")
            self.log(f"Модуль n ({self.keys.n.bit_length()} біт): {self.keys.n}")
            self.log(f"Відкритий ключ: (e={self.keys.e}, n={self.keys.n})")
            self.log(f"Секретний ключ: (d={self.keys.d}, n={self.keys.n})")
            self.log("=" * 72)
        else:
            try:
                p = int(self.p_entry.get().strip())
                q = int(self.q_entry.get().strip())
                e_val = int(self.e_entry.get().strip() or str(DEFAULT_E_EDU))
                msg = self.text_input.get("1.0", tk.END).strip()
                self.keys = RSAKeyPair(p, q, e=e_val, message=msg)
                self.current_mode = "edu"
                self.key_info_var.set(
                    f"p={self.keys.p}, q={self.keys.q}, n={self.keys.n}, φ={self.keys.phi}, e={self.keys.e}, d={self.keys.d}"
                )
                self.log("=" * 72)
                self.log(f"✔ Навчальні параметри RSA успішно валідовано та розраховано:")
                self.log(f"p={p}, q={q}, n={self.keys.n}, φ(n)={self.keys.phi}, e={self.keys.e}, d={self.keys.d}")
                self.log(f"Відкритий ключ (e, n): ({self.keys.e}, {self.keys.n})")
                self.log(f"Секретний ключ (d, n): ({self.keys.d}, {self.keys.n})")
                self.log("=" * 72)
            except Exception as ex:
                messagebox.showerror("Помилка валідації параметрів", str(ex))

    def get_msg(self):
        m = self.text_input.get("1.0", tk.END).strip()
        if not m:
            messagebox.showwarning("Помилка", "Введіть текст повідомлення!")
            return None
        return m

    def handle_encrypt(self):
        msg = self.get_msg()
        if not msg:
            return
        if self.current_mode == "edu":
            c = encrypt_text_educational(msg, self.keys.public_key)
        else:
            c = encrypt_text_real(msg, self.keys.public_key)

        self.last_ciphertext_numbers = c
        c_str = ", ".join(str(x) for x in c)
        self.cipher_input.delete("1.0", tk.END)
        self.cipher_input.insert(tk.END, c_str)

        self.log("=" * 72)
        self.log(f"🔒 ШИФРУВАННЯ RSA ({'Навчальний' if self.current_mode == 'edu' else '1024-бітний'} режим):")
        self.log(f"Шифротекст (перші 12 чисел):\n{c[:12]}...")
        self.log("Числа шифротексту розміщено у спеціальному полі.")
        self.log("=" * 72)

    def handle_decrypt(self):
        raw_c = self.cipher_input.get("1.0", tk.END).strip()
        if not raw_c:
            if self.last_ciphertext_numbers:
                numbers = self.last_ciphertext_numbers
            else:
                messagebox.showwarning("Помилка", "Поле шифротексту порожнє!")
                return
        else:
            try:
                cleaned = raw_c.replace(",", " ").replace("[", "").replace("]", "")
                numbers = [int(token) for token in cleaned.split() if token]
            except ValueError:
                messagebox.showerror("Помилка", "Некоректні числа шифротексту!")
                return

        self.log("=" * 72)
        self.log(f"🔓 ДЕШИФРУВАННЯ RSA (отримано {len(numbers)} чисел):")
        try:
            if self.current_mode == "edu":
                p = decrypt_text_educational(numbers, self.keys.private_key)
            else:
                p = decrypt_text_real(numbers, self.keys.private_key)
            self.log(f"Відновлений відкритий текст:\n«{p}»")
        except Exception as ex:
            self.log(f"✖ Помилка дешифрування: {ex}")
        self.log("=" * 72)

    def handle_sign_direct(self):
        msg = self.get_msg()
        if not msg:
            return
        if self.current_mode == "edu":
            sig = sign_direct_educational(msg, self.keys.private_key)
            valid = verify_direct_educational(msg, sig, self.keys.public_key)
        else:
            sig = sign_direct_real(msg, self.keys.private_key)
            valid = verify_direct_real(msg, sig, self.keys.public_key)

        self.log("=" * 72)
        self.log("✍ ЕЦП ЗА МЕТОДИЧКОЮ: S = M^d mod n (прямий числовий підпис):")
        self.log(f"Підпис повідомлення S (перші 10 значень): {sig[:10]}...")
        self.log(f"Результат верифікації (M == S^e mod n): {'✔ ПІДТВЕРДЖЕНО' if valid else '✖ ПРОВАЛ'}")
        self.log("=" * 72)

    def handle_sign_hash(self):
        msg = self.get_msg()
        if not msg:
            return
        sig = sign_message_hash(msg, self.keys.private_key)
        valid = verify_signature_hash(msg, sig, self.keys.public_key)
        self.log("=" * 72)
        self.log("🔐 ЕЦП ХЕША SHA-256: S = H(M)^d mod n:")
        self.log(f"Значення підпису S: {sig}")
        self.log(f"Результат верифікації S^e mod n == H(M): {'✔ ПІДТВЕРДЖЕНО' if valid else '✖ ПРОВАЛ'}")
        if self.current_mode == "edu":
            self.log(f"⚠️ Застереження: при n={self.keys.n} ймовірність випадкової колізії хеша ≈ 1/n ({100/self.keys.n:.4f}%).")
        self.log("=" * 72)

    def handle_tamper_test(self):
        msg = self.get_msg()
        if not msg:
            return
        tampered = msg + "!"
        self.log("=" * 72)
        self.log("🛑 КОМПЛЕКСНА ПЕРЕВІРКА ПІДРОБКИ ПОВІДОМЛЕННЯ (ДОДАНО ЗНАК «!»):")

        # 1. Прямий підпис
        if self.current_mode == "edu":
            sig_d = sign_direct_educational(msg, self.keys.private_key)
            valid_d = verify_direct_educational(tampered, sig_d, self.keys.public_key)
        else:
            sig_d = sign_direct_real(msg, self.keys.private_key)
            valid_d = verify_direct_real(tampered, sig_d, self.keys.public_key)
        self.log(f"1. Прямий числовий підпис (S=M^d): {'ПРИЙНЯТО' if valid_d else '✔ ВІДХИЛЕНО (порушення цілісності!)'}")

        # 2. Хеш-підпис
        sig_h = sign_message_hash(msg, self.keys.private_key)
        valid_h = verify_signature_hash(tampered, sig_h, self.keys.public_key)
        self.log(f"2. Хеш-підпис SHA-256          : {'ПРИЙНЯТО' if valid_h else '✔ ВІДХИЛЕНО (хеш не збігається!)'}")
        self.log("=" * 72)

    def handle_factorize(self):
        self.log("=" * 72)
        self.log(f"🔍 СПРОБА ФАКТОРИЗАЦІЇ МОДУЛЯ n = {self.keys.n} ({self.keys.n.bit_length()} біт)...")
        if self.keys.n < 10**12:
            res = factorize_modulus(self.keys.n)
            if res:
                f1, f2, dt = res
                self.log(f"✔ УСПІШНО ЗЛАМАНО! Множники: {f1} × {f2} за {dt*1000:.4f} мс.")
                self.log(f"  Обчислено φ = ({f1}-1)*({f2}-1) = {(f1-1)*(f2-1)}, секретний ключ d повністю скомпрометовано.")
        else:
            self.log(f"Модуль n = {self.keys.n.bit_length()} біт занадто великий для факторизації методом пробного поділу.")
            self.log("1024-бітні модулі вважаються недостатньо стійкими проти потужних зловмисників, актуальний мінімум 2048 біт.")
            self.log("Режим 1024 біт використовується лише для навчальної демонстрації.")
        self.log("=" * 72)

    def handle_auto_demo(self):
        self.clear_output()
        self.log("▶ Запуск автоматичної демонстрації ЛР № 6...")
        self.handle_encrypt()
        self.handle_sign_direct()
        self.handle_sign_hash()
        self.handle_tamper_test()
        self.handle_factorize()


def launch_gui():
    if not HAS_TKINTER:
        print("Графічний інтерфейс Tkinter недоступний у цьому середовищі.")
        print("Використовуйте режим автоматичної демонстрації: python crypto_labs/lab6_rsa.py --demo")
        return
    root = tk.Tk()
    app = RSAGUI(root)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("--demo", "-d", "demo"):
        sys.stdout.reconfigure(encoding="utf-8")
        run_auto_demo()
    else:
        launch_gui()
