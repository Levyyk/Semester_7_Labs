"""
Лабораторна робота № 1: Дослідження шифру зсуву (шифр Цезаря)
Дисципліна: Захист інформації в інфокомунікаціях
Виконавець: студент 3-го курсу НУ «Львівська політехніка»

Графічний інтерфейс (GUI на Tkinter) + консольний режим (--demo).
Шифрування: C = (P + k) mod 33
Дешифрування: P = (C - k) mod 33
"""

import sys
import time
import random
import re
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

# ----------------- КОНСТАНТИ ЗА ЗАМОВЧУВАННЯМ -----------------
UKRAINIAN_ALPHABET = "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя"
ALPHABET_LEN = len(UKRAINIAN_ALPHABET)  # 33

DEFAULT_TEXT = (
    "Криптографія є важливою складовою сучасних інформаційно-комунікаційних "
    "систем і забезпечує конфіденційність, цілісність та автентичність переданих даних у мережі Інтернет. "
    "Шифр Цезаря є найдавнішим відомим моноалфавітним шифром зсуву, де кожен символ замінюється іншим."
)
DEFAULT_KEY = 7

# Статистичні частоти літер української мови
UKRAINIAN_FREQUENCIES = {
    'о': 0.0928, 'а': 0.0834, 'н': 0.0654, 'і': 0.0623, 'и': 0.0612,
    'т': 0.0560, 'в': 0.0523, 'р': 0.0475, 'е': 0.0463, 'с': 0.0414,
    'к': 0.0401, 'л': 0.0371, 'д': 0.0355, 'у': 0.0326, 'м': 0.0311,
    'п': 0.0284, 'я': 0.0216, 'з': 0.0210, 'ь': 0.0183, 'б': 0.0170,
    'г': 0.0160, 'ч': 0.0139, 'й': 0.0124, 'х': 0.0117, 'ц': 0.0102,
    'ж': 0.0091, 'ш': 0.0089, 'ю': 0.0070, 'ї': 0.0062, 'є': 0.0055,
    'щ': 0.0049, 'ф': 0.0028, 'ґ': 0.0001
}

COMMON_WORDS = {
    "і", "в", "та", "що", "на", "не", "до", "як", "за", "по", "це", "з", "але", "від", "для",
    "я", "ми", "ти", "ви", "він", "вона", "воно", "вони", "так", "ні", "чи", "де", "тут", "там",
    "хочу", "був", "була", "було", "були", "буде", "є", "про", "під", "при", "після"
}


# ----------------- БАЗОВІ ФУНКЦІЇ ШИФРУВАННЯ -----------------
def encrypt_caesar(text: str, key: int) -> str:
    """Шифрування: C = (P + k) mod 33. Регістр зберігається, спецсимволи на місці."""
    key = key % ALPHABET_LEN
    result = []
    for char in text:
        is_upper = char.isupper()
        lower_char = char.lower()
        if lower_char in UKRAINIAN_ALPHABET:
            p_idx = UKRAINIAN_ALPHABET.index(lower_char)
            c_idx = (p_idx + key) % ALPHABET_LEN
            c_char = UKRAINIAN_ALPHABET[c_idx]
            result.append(c_char.upper() if is_upper else c_char)
        else:
            result.append(char)
    return "".join(result)


def decrypt_caesar(ciphertext: str, key: int) -> str:
    """Дешифрування: P = (C - k) mod 33."""
    key = key % ALPHABET_LEN
    result = []
    for char in ciphertext:
        is_upper = char.isupper()
        lower_char = char.lower()
        if lower_char in UKRAINIAN_ALPHABET:
            c_idx = UKRAINIAN_ALPHABET.index(lower_char)
            p_idx = (c_idx - key) % ALPHABET_LEN
            p_char = UKRAINIAN_ALPHABET[p_idx]
            result.append(p_char.upper() if is_upper else p_char)
        else:
            result.append(char)
    return "".join(result)


def calculate_chi_squared(text: str) -> float:
    """Обчислює критерій хі-квадрат (chi-squared) для тексту."""
    letters = [ch.lower() for ch in text if ch.lower() in UKRAINIAN_ALPHABET]
    n = len(letters)
    if n == 0:
        return float('inf')

    counts = {ch: 0 for ch in UKRAINIAN_ALPHABET}
    for ch in letters:
        counts[ch] += 1

    chi_sq = 0.0
    for ch in UKRAINIAN_ALPHABET:
        expected = n * UKRAINIAN_FREQUENCIES.get(ch, 0.0001)
        observed = counts[ch]
        chi_sq += ((observed - expected) ** 2) / expected
    return chi_sq


def count_common_words(text: str) -> int:
    """Підраховує входження частих українських слів."""
    words = re.findall(r'[а-яіїєґ]+', text.lower())
    return sum(1 for w in words if w in COMMON_WORDS)


def brute_force_attack(ciphertext: str):
    """Атака повним перебором (Brute Force) по 33 ключах."""
    results = []
    for k in range(ALPHABET_LEN):
        decrypted = decrypt_caesar(ciphertext, k)
        chi = calculate_chi_squared(decrypted)
        words_cnt = count_common_words(decrypted)
        results.append((k, decrypted, chi, words_cnt))
    return results


def find_best_key(brute_results):
    """Знаходить найбільш імовірний ключ (пріоритет за знайденими словами та мінімумом хі-квадрат)."""
    sorted_by_score = sorted(brute_results, key=lambda x: (-x[3], x[2]))
    return sorted_by_score[0]


# ----------------- КОНСОЛЬНА ДЕМОНСТРАЦІЯ -----------------
def run_auto_demo(text: str = DEFAULT_TEXT, key: int = DEFAULT_KEY):
    print("=" * 75)
    print("      АВТОМАТИЧНА ДЕМОНСТРАЦІЯ: ЛАБОРАТОРНА РОБОТА № 1 (ШИФР ЦЕЗАРЯ)")
    print("=" * 75)
    print(f"Потужність алфавіту (n): {ALPHABET_LEN} літери ({UKRAINIAN_ALPHABET})")
    print(f"Довжина вхідного тексту: {len(text)} символів")
    print(f"Ключ (зсув k): {key}")
    print("-" * 75)

    ciphertext = encrypt_caesar(text, key)
    print(f"ШИФРОТЕКСТ (C = (P + {key}) mod {ALPHABET_LEN}):\n{ciphertext}\n")

    decrypted = decrypt_caesar(ciphertext, key)
    print(f"ДЕШИФРОВАНИЙ ТЕКСТ (P = (C - {key}) mod {ALPHABET_LEN}):\n{decrypted[:120]}...\n")

    assert decrypted == text, "Помилка дешифрування!"
    print("✔ [Вбудована перевірка]: Дешифрований текст повністю ідентичний оригіналу!\n")

    t0 = time.perf_counter()
    brute_res = brute_force_attack(ciphertext)
    t_elapsed = time.perf_counter() - t0

    print("АТАКА ПОВНИМ ПЕРЕБОРОМ (BRUTE-FORCE) ВСІХ 33 ВАРІАНТІВ:")
    for k, dec_text, chi, w_cnt in brute_res:
        marker = " <--- ІСТИННИЙ КЛЮЧ" if k == key else ""
        print(f"Ключ {k:2d} | χ²: {chi:9.2f} | Слів: {w_cnt:2d} | {dec_text[:40]}...{marker}")

    best_k, best_text, best_chi, best_words = find_best_key(brute_res)
    print("-" * 75)
    print(f"✔ АВТОМАТИЧНО ВИЗНАЧЕНИЙ КЛЮЧ: k = {best_k} (істинний: k = {key}, χ² = {best_chi:.2f}, знайдено слів: {best_words})")
    print(f"Час повного перебору (33 варіанти): {t_elapsed * 1000:.4f} мс.")
    print("=" * 75)


# ----------------- ГРАФІЧНИЙ ІНТЕРФЕЙС (GUI TKINTER) -----------------
class CaesarGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Лабораторна робота № 1: Шифр Цезаря (НУ «Львівська політехніка»)")
        self.root.geometry("880x750")
        self.root.minsize(780, 620)

        style = ttk.Style()
        style.theme_use("clam")

        main_frame = ttk.Frame(root, padding=12)
        main_frame.pack(fill=tk.BOTH, expand=True)

        header_label = ttk.Label(
            main_frame,
            text="Лабораторна робота № 1: Дослідження шифру зсуву (Цезаря)\n"
                 "C = (P + k) mod 33  |  P = (C - k) mod 33",
            font=("Segoe UI", 11, "bold"),
            justify=tk.CENTER
        )
        header_label.pack(pady=(0, 8))

        # 1. Відкритий текст (P)
        p_group = ttk.LabelFrame(main_frame, text=" 1. Відкритий текст (Plaintext - P) ", padding=6)
        p_group.pack(fill=tk.BOTH, expand=False, pady=3)

        self.text_p = scrolledtext.ScrolledText(p_group, height=3, font=("Segoe UI", 10), wrap=tk.WORD)
        self.text_p.pack(fill=tk.BOTH, expand=True)
        self.text_p.insert(tk.END, DEFAULT_TEXT)

        # 2. Шифротекст (C)
        c_group = ttk.LabelFrame(main_frame, text=" 2. Шифротекст (Ciphertext - C) ", padding=6)
        c_group.pack(fill=tk.BOTH, expand=False, pady=3)

        self.text_c = scrolledtext.ScrolledText(c_group, height=3, font=("Segoe UI", 10), wrap=tk.WORD, bg="#F0F4F8")
        self.text_c.pack(fill=tk.BOTH, expand=True)

        # 3. Налаштування ключа
        settings_group = ttk.LabelFrame(main_frame, text=" 3. Налаштування ключа зсуву k (1 .. 32) ", padding=6)
        settings_group.pack(fill=tk.X, pady=3)

        k_frame = ttk.Frame(settings_group)
        k_frame.pack(fill=tk.X)

        ttk.Label(k_frame, text="Ключ k:", font=("Segoe UI", 10, "bold")).pack(side=tk.LEFT, padx=5)
        self.key_var = tk.IntVar(value=DEFAULT_KEY)
        self.key_spin = ttk.Spinbox(k_frame, from_=1, to=32, textvariable=self.key_var, width=6, font=("Segoe UI", 10))
        self.key_spin.pack(side=tk.LEFT, padx=5)

        ttk.Button(k_frame, text="🎲 Випадковий ключ", command=self.generate_random_key).pack(side=tk.LEFT, padx=6)
        ttk.Button(k_frame, text="📋 Скинути до типового тексту", command=self.reset_default_text).pack(side=tk.RIGHT, padx=5)

        # 4. Кнопки дій
        btn_frame = ttk.Frame(main_frame, padding=2)
        btn_frame.pack(fill=tk.X, pady=4)

        ttk.Button(btn_frame, text="🔒 Зашифрувати (P → C)", command=self.handle_encrypt).pack(side=tk.LEFT, padx=3, expand=True, fill=tk.X)
        ttk.Button(btn_frame, text="🔓 Дешифрувати (C → P)", command=self.handle_decrypt).pack(side=tk.LEFT, padx=3, expand=True, fill=tk.X)
        ttk.Button(btn_frame, text="⚡ Атака Brute-Force (33 ключі) + Хі-квадрат", command=self.handle_brute_force).pack(side=tk.LEFT, padx=3, expand=True, fill=tk.X)
        ttk.Button(btn_frame, text="▶ Автоматична демонстрація", command=self.handle_auto_demo).pack(side=tk.LEFT, padx=3, expand=True, fill=tk.X)
        ttk.Button(btn_frame, text="🧹 Очистити протокол", command=self.clear_output).pack(side=tk.LEFT, padx=3)

        # 5. Протокол результатів
        output_group = ttk.LabelFrame(main_frame, text=" 4. Протокол роботи програми та результати криптоаналізу ", padding=6)
        output_group.pack(fill=tk.BOTH, expand=True, pady=3)

        self.text_output = scrolledtext.ScrolledText(output_group, font=("Consolas", 9), wrap=tk.WORD, bg="#FDFDFD")
        self.text_output.pack(fill=tk.BOTH, expand=True)

        self.log("Програма готова до роботи.")
        self.log("Введіть відкритий текст у Поле 1, оберіть ключ k і натисніть «🔒 Зашифрувати (P → C)».\n")

    def log(self, message: str):
        self.text_output.insert(tk.END, message + "\n")
        self.text_output.see(tk.END)

    def clear_output(self):
        self.text_output.delete("1.0", tk.END)

    def reset_default_text(self):
        self.text_p.delete("1.0", tk.END)
        self.text_p.insert(tk.END, DEFAULT_TEXT)
        self.text_c.delete("1.0", tk.END)
        self.key_var.set(DEFAULT_KEY)
        self.log("✔ Відновлено типовий текст та ключ k = 7.")

    def generate_random_key(self):
        new_k = random.randint(1, 32)
        self.key_var.set(new_k)
        self.log(f"🎲 Згенеровано випадковий ключ: k = {new_k}")

    def get_key(self):
        try:
            k = int(self.key_var.get())
            if not (1 <= k <= 32):
                messagebox.showerror("Помилка", "Ключ повинен бути цілим числом від 1 до 32!")
                return None
            return k
        except ValueError:
            messagebox.showerror("Помилка", "Некоректний формат ключа!")
            return None

    def handle_encrypt(self):
        p_text = self.text_p.get("1.0", tk.END).strip()
        if not p_text:
            messagebox.showwarning("Попередження", "Поле «Відкритий текст (P)» порожнє!")
            return
        k = self.get_key()
        if k is None:
            return

        if len(p_text) < 100:
            self.log(f"⚠ ПОПЕРЕДЖЕННЯ: Довжина тексту ({len(p_text)} симв.) менша за 100 символів (за методичкою рекомендовано >= 100).")

        c = encrypt_caesar(p_text, k)
        self.text_c.delete("1.0", tk.END)
        self.text_c.insert(tk.END, c)

        self.log("=" * 65)
        self.log(f"🔒 ШИФРУВАННЯ ВИКОНАНО (ключ k = {k}):")
        self.log(f"Відкритий текст  : {p_text}")
        self.log(f"Шифротекст       : {c}")
        # Перевірка
        check_p = decrypt_caesar(c, k)
        if check_p == p_text:
            self.log("✔ [Вбудована перевірка]: Дешифрування повернуло точний вихідний текст.")
        self.log("=" * 65)

    def handle_decrypt(self):
        c_text = self.text_c.get("1.0", tk.END).strip()
        if not c_text:
            # Якщо поле C порожнє, спробувати взяти з P
            c_text = self.text_p.get("1.0", tk.END).strip()
            if not c_text:
                messagebox.showwarning("Попередження", "Немає шифротексту для дешифрування!")
                return

        k = self.get_key()
        if k is None:
            return

        p = decrypt_caesar(c_text, k)
        self.text_p.delete("1.0", tk.END)
        self.text_p.insert(tk.END, p)

        self.log("=" * 65)
        self.log(f"🔓 ДЕШИФРУВАННЯ ВИКОНАНО (ключ k = {k}):")
        self.log(f"Шифротекст       : {c_text}")
        self.log(f"Відновлений текст: {p}")
        self.log("=" * 65)

    def handle_brute_force(self):
        c_text = self.text_c.get("1.0", tk.END).strip()
        if not c_text:
            # Автоматично зашифрувати текст з P
            p_text = self.text_p.get("1.0", tk.END).strip()
            if not p_text:
                messagebox.showwarning("Попередження", "Введіть текст для атаки!")
                return
            k = self.get_key() or DEFAULT_KEY
            c_text = encrypt_caesar(p_text, k)
            self.text_c.delete("1.0", tk.END)
            self.text_c.insert(tk.END, c_text)

        k = self.get_key() or DEFAULT_KEY

        self.log("=" * 75)
        self.log(f"⚡ АТАКА ПОВНИМ ПЕРЕБОРОМ (BRUTE-FORCE) ДЛЯ ШИФРОТЕКСТУ:\n  «{c_text}»")
        self.log(f"{'Ключ':<6} | {'Хі-квадрат (χ²)':<16} | {'Слів':<6} | {'Фрагмент тексту'}")
        self.log("-" * 75)

        t0 = time.perf_counter()
        results = brute_force_attack(c_text)
        dt = time.perf_counter() - t0

        for candidate_k, dec_t, chi, w_cnt in results:
            preview = dec_t[:38].replace("\n", " ") + "..."
            marker = " <=== ПРАВИЛЬНИЙ КЛЮЧ" if candidate_k == k else ""
            self.log(f"{candidate_k:<6} | {chi:<16.2f} | {w_cnt:<6} | {preview}{marker}")

        best_k, best_t, best_chi, best_words = find_best_key(results)
        self.log("-" * 75)
        self.log(f"✔ АВТОМАТИЧНО ВИЗНАЧЕНИЙ КЛЮЧ: k = {best_k}")
        self.log(f"  • Оцінка хі-квадрат (χ²): {best_chi:.2f}")
        self.log(f"  • Знайдено поширених українських слів: {best_words}")
        self.log(f"  • Час повного перебору всіх 33 ключів: {dt * 1000:.4f} мс")
        self.log(f"  • Розшифрований текст: «{best_t}»")
        if best_k == k:
            self.log("  ✔ ВЕРДИКТ: Ключ розкрито абсолютно точно!")
        self.log("=" * 75)

    def handle_auto_demo(self):
        self.clear_output()
        self.log("▶ Запуск автоматичного сценарію демонстрації...\n")
        self.reset_default_text()
        self.handle_encrypt()
        self.handle_brute_force()


def launch_gui():
    root = tk.Tk()
    app = CaesarGUI(root)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("--demo", "-d", "demo"):
        sys.stdout.reconfigure(encoding="utf-8")
        run_auto_demo()
    else:
        launch_gui()
