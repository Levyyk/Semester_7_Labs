"""
Лабораторна робота № 3: Дослідження шифрів переставляння (транспозиційні шифри)
Дисципліна: Захист інформації в інфокомунікаціях
Виконавець: студент 3-го курсу НУ «Львівська політехніка»

Графічний інтерфейс (GUI на Tkinter) + консольний режим (--demo).
Маршрутні («змійка», «спіраль»), стовпцеві з ключем та подвійні перестановки.
Візуалізація матриць ДО і ПІСЛЯ, доведення збереження частот (33 літери),
аналіз впливу довжини ключа (n!, повний перебір <= 8 та екстраполяція).
"""

import sys
import time
import math
import random
import itertools
from collections import Counter

# G1: Безпечні імпорти tkinter
try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, messagebox
    TKINTER_AVAILABLE = True
except ImportError:
    tk = None
    ttk = None
    scrolledtext = None
    messagebox = None
    TKINTER_AVAILABLE = False

# ----------------- КОНСТАНТИ ТА АЛФАВІТ -----------------
UKRAINIAN_ALPHABET = "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя"
UKR_CHAR_ORDER = {ch: idx for idx, ch in enumerate(UKRAINIAN_ALPHABET)}

DEFAULT_TEXT = (
    "Шифри переставляння змінюють порядок розташування символів у повідомленні, "
    "але зберігають незмінними самі символи та їхні абсолютні частоти появи. "
    "Це принципова відмінність від шифрів заміни."
)
DEFAULT_KEYWORD = "КАФЕДРА"
DEFAULT_KEYWORD2 = "ЗАХИСТ"
DEFAULT_COLS = 7
PADDING_CHAR = "§"

COMMON_WORDS_UKR = {
    "і", "в", "на", "що", "та", "не", "це", "за", "до", "як", "про", "але", "при", "від",
    "по", "із", "чи", "де", "ми", "ви", "він", "вона", "вони", "його", "її", "їх", "для",
    "шифри", "текст", "захист", "порядок", "повідомленні", "символів", "появи"
}


# ----------------- МАТРИЧНІ ОПЕРАЦІЇ ТА ПАДДІНГ -----------------
def pad_text(text: str, cols: int) -> tuple[str, int]:
    rem = len(text) % cols
    needed = (cols - rem) % cols
    padded = text + (PADDING_CHAR * needed)
    return padded, len(padded) // cols


def build_matrix(text_padded: str, rows: int, cols: int) -> list[list[str]]:
    return [list(text_padded[r * cols:(r + 1) * cols]) for r in range(rows)]


def format_matrix_display(matrix: list[list[str]], col_headers: list[str] = None) -> str:
    rows = len(matrix)
    if rows == 0:
        return ""
    cols = len(matrix[0])
    lines = []
    if col_headers:
        lines.append("  Стовпці: | " + " | ".join(f"{h:^3}" for h in col_headers) + " |")
        lines.append("  " + "-" * (cols * 6 + 12))
    for r in range(rows):
        row_str = " | ".join(f"{matrix[r][c]:^3}" for c in range(cols))
        lines.append(f"  Рядок {r+1:02d}:| {row_str} |")
    return "\n".join(lines)


# ----------------- СОРТУВАННЯ КЛЮЧА ЗА УКРАЇНСЬКИМ АЛФАВІТОМ (Item 2) -----------------
def keyword_to_order(keyword: str) -> list[int]:
    """Сортує за позицією літери в UKRAINIAN_ALPHABET, а не за Unicode."""
    indexed = list(enumerate(keyword.lower()))
    sorted_by_char = sorted(indexed, key=lambda x: UKR_CHAR_ORDER.get(x[1], ord(x[1])))
    return [item[0] for item in sorted_by_char]


# ----------------- 1. МАРШРУТНА ПЕРЕСТАНОВКА -----------------
def encrypt_route_snake(text: str, cols: int = DEFAULT_COLS):
    padded, rows = pad_text(text, cols)
    matrix = build_matrix(padded, rows, cols)
    result = []
    for c in range(cols):
        if c % 2 == 0:
            for r in range(rows):
                result.append(matrix[r][c])
        else:
            for r in range(rows - 1, -1, -1):
                result.append(matrix[r][c])
    return "".join(result), len(text), matrix


def decrypt_route_snake(ciphertext: str, cols: int, orig_len: int):
    rows = len(ciphertext) // cols
    matrix = [[""] * cols for _ in range(rows)]
    idx = 0
    for c in range(cols):
        if c % 2 == 0:
            for r in range(rows):
                matrix[r][c] = ciphertext[idx]
                idx += 1
        else:
            for r in range(rows - 1, -1, -1):
                matrix[r][c] = ciphertext[idx]
                idx += 1
    recovered = "".join("".join(row) for row in matrix)
    return recovered[:orig_len], matrix


def encrypt_route_spiral(text: str, cols: int = DEFAULT_COLS):
    padded, rows = pad_text(text, cols)
    matrix = build_matrix(padded, rows, cols)
    top, bottom, left, right = 0, rows - 1, 0, cols - 1
    result = []
    while top <= bottom and left <= right:
        for c in range(left, right + 1):
            result.append(matrix[top][c])
        top += 1
        for r in range(top, bottom + 1):
            result.append(matrix[r][right])
        right -= 1
        if top <= bottom:
            for c in range(right, left - 1, -1):
                result.append(matrix[bottom][c])
            bottom -= 1
        if left <= right:
            for r in range(bottom, top - 1, -1):
                result.append(matrix[r][left])
            left += 1
    return "".join(result), len(text), matrix


def decrypt_route_spiral(ciphertext: str, cols: int, orig_len: int):
    rows = len(ciphertext) // cols
    matrix = [[""] * cols for _ in range(rows)]
    top, bottom, left, right = 0, rows - 1, 0, cols - 1
    idx = 0
    while top <= bottom and left <= right:
        for c in range(left, right + 1):
            matrix[top][c] = ciphertext[idx]
            idx += 1
        top += 1
        for r in range(top, bottom + 1):
            matrix[r][right] = ciphertext[idx]
            idx += 1
        right -= 1
        if top <= bottom:
            for c in range(right, left - 1, -1):
                matrix[bottom][c] = ciphertext[idx]
                idx += 1
            bottom -= 1
        if left <= right:
            for r in range(bottom, top - 1, -1):
                matrix[r][left] = ciphertext[idx]
                idx += 1
            left += 1
    recovered = "".join("".join(row) for row in matrix)
    return recovered[:orig_len], matrix


# ----------------- 2. СТОВПЦЕВА ПЕРЕСТАНОВКА (ТАБЛИЦІ ДО І ПІСЛЯ) -----------------
def encrypt_columnar(text: str, keyword: str):
    cols = len(keyword)
    padded, rows = pad_text(text, cols)
    matrix_before = build_matrix(padded, rows, cols)
    order = keyword_to_order(keyword)

    # Матриця після перестановки стовпців
    matrix_after = [[""] * cols for _ in range(rows)]
    for new_c, orig_c in enumerate(order):
        for r in range(rows):
            matrix_after[r][new_c] = matrix_before[r][orig_c]

    result = []
    for col_idx in order:
        for r in range(rows):
            result.append(matrix_before[r][col_idx])
    return "".join(result), len(text), matrix_before, matrix_after


def decrypt_columnar(ciphertext: str, keyword: str, orig_len: int):
    cols = len(keyword)
    rows = len(ciphertext) // cols
    order = keyword_to_order(keyword)
    matrix = [[""] * cols for _ in range(rows)]
    idx = 0
    for col_idx in order:
        for r in range(rows):
            matrix[r][col_idx] = ciphertext[idx]
            idx += 1
    recovered = "".join("".join(row) for row in matrix)
    return recovered[:orig_len], matrix


# ----------------- 3. ПОДВІЙНА ПЕРЕСТАНОВКА (ВИПРАВЛЕННЯ БАГУ - Item 1) -----------------
def encrypt_double_transposition(text: str, kw1: str, kw2: str) -> tuple[str, int]:
    c1, _, _, _ = encrypt_columnar(text, kw1)
    c2, _, _, _ = encrypt_columnar(c1, kw2)
    return c2, len(text)


def decrypt_double_transposition(ciphertext: str, kw1: str, kw2: str, orig_len: int) -> str:
    """
    Виправлений алгоритм дешифрування подвійної перестановки:
    Довжина проміжного тексту c1 розраховується як math.ceil(orig_len / cols1) * cols1,
    що усуває збій дешифрування, коли паддінг другого проходу >= довжини першого ключа.
    """
    cols1 = len(kw1)
    len1 = math.ceil(orig_len / cols1) * cols1
    p2, _ = decrypt_columnar(ciphertext, kw2, len1)
    p1, _ = decrypt_columnar(p2, kw1, orig_len)
    return p1


# ----------------- 4. ПОВНЕ ЧАСТОТНЕ ПОРІВНЯННЯ (УСІ 33 ЛІТЕРИ - Item 5) -----------------
def compare_frequencies_full(text_orig: str, ciphertext: str) -> tuple[bool, str]:
    c_clean = ciphertext.replace(PADDING_CHAR, "")
    letters_o = [ch.lower() for ch in text_orig if ch.lower() in UKRAINIAN_ALPHABET]
    letters_c = [ch.lower() for ch in c_clean if ch.lower() in UKRAINIAN_ALPHABET]

    cnt_orig = Counter(letters_o)
    cnt_ciph = Counter(letters_c)
    tot_o = len(letters_o)
    tot_c = len(letters_c)

    is_identical = (cnt_orig == cnt_ciph) and (tot_o == tot_c)

    sorted_letters = sorted(UKRAINIAN_ALPHABET, key=lambda x: cnt_orig.get(x, 0), reverse=True)

    lines = []
    lines.append("=" * 80)
    lines.append(f"{'№':<3} | {'Літера':<8} | {'К-сть P':<8} | {'% P':<8} | {'К-сть C':<8} | {'% C':<8} | {'Різниця':<8}")
    lines.append("-" * 80)

    for idx, ch in enumerate(sorted_letters, 1):
        co = cnt_orig.get(ch, 0)
        cc = cnt_ciph.get(ch, 0)
        po = (co / tot_o * 100) if tot_o > 0 else 0.0
        pc = (cc / tot_c * 100) if tot_c > 0 else 0.0
        diff = abs(po - pc)
        lines.append(f"{idx:<3} | {ch.upper():<8} | {co:<8} | {po:>6.2f}% | {cc:<8} | {pc:>6.2f}% | {diff:>6.2f}%")

    lines.append("=" * 80)
    verdict = "✔ ПІДСУМОК: Частоти символів на 100% ІДЕНТИЧНІ (шифри переставляння не змінюють монограмні частоти мови)."
    lines.append(verdict)
    return is_identical, "\n".join(lines)


# ----------------- 5. АНАЛІЗ ВПЛИВУ ДОВЖИНИ КЛЮЧА (n! ТА ПЕРЕБІР - Item 3) -----------------
def analyze_key_length_impact(sample_text: str = DEFAULT_TEXT) -> str:
    lengths = [3, 4, 5, 6, 8, 10, 12, 15]
    lines = []
    lines.append("=" * 90)
    lines.append("        АНАЛІЗ ВПЛИВУ ДОВЖИНИ КЛЮЧА НА КРИПТОСТІЙКІСТЬ ШИФРУ ПЕРЕСТАВЛЯННЯ")
    lines.append("=" * 90)
    lines.append(f"{'Довжина k':<10} | {'Простір n!':<18} | {'Час / Оцінка':<22} | {'Результат / Розпізнавання'}")
    lines.append("-" * 90)

    # Вимірюємо швидкість на переборі для k=6 або k=8
    test_key = "ЗАХИСТ"
    c_test, orig_l, _, _ = encrypt_columnar(sample_text, test_key)

    speed_perms_per_sec = 250000.0  # базове значення за замовчуванням

    for k in lengths:
        n_fact = math.factorial(k)
        if k <= 8:
            # Реальний повний перебір перестановок з дешифруванням і розпізнаванням за частими словами
            k_word = "АБВГҐДЕЖЗИ"[:k]
            true_order = tuple(keyword_to_order(k_word))
            c_k, l_k, _, _ = encrypt_columnar(sample_text, k_word)
            rows_k = len(c_k) // k
            cols_c = [c_k[i * rows_k:(i + 1) * rows_k] for i in range(k)]

            t0 = time.perf_counter()
            best_score = -1
            best_match = ""
            best_p = None
            cols_in_pos = [None] * k

            for p in itertools.permutations(range(k)):
                for orig_col, blk in zip(p, cols_c):
                    cols_in_pos[orig_col] = blk
                cand = "".join("".join(row) for row in zip(*cols_in_pos))[:l_k]
                words = [w.strip(".,!?:- ") for w in cand.lower().split()]
                score = sum(1 for w in words if w in COMMON_WORDS_UKR)
                if score > best_score:
                    best_score = score
                    best_match = cand
                    best_p = p

            dt = time.perf_counter() - t0
            if dt > 0:
                speed_perms_per_sec = n_fact / dt

            # Перевірка: знайдена перестановка збігається зі справжнім порядком
            assert best_p == true_order, f"Помилка: знайдена перестановка {best_p} != {true_order}"

            if k <= 6:
                lines.append(f"{k:<10} | {n_fact:<18} | {dt*1000:>9.2f} мс            | Розпізнано правильний текст ({best_score} слів)")
            else:
                lines.append(f"{k:<10} | {n_fact:<18} | {dt:>9.2f} сек           | 40 320 перебрано та дешифровано реально ({best_score} слів)")

        else:
            # Екстраполяція за виміряною швидкістю k=8
            extrap_sec = n_fact / speed_perms_per_sec
            if extrap_sec < 60:
                t_str = f"{extrap_sec:.2f} сек (екстрап.)"
            elif extrap_sec < 3600:
                t_str = f"{extrap_sec/60:.2f} хв (екстрап.)"
            elif extrap_sec < 86400 * 365:
                t_str = f"{extrap_sec/86400:.2f} днів (екстрап.)"
            else:
                t_str = f"{extrap_sec/(86400*365):.2e} років (екстрап.)"
            lines.append(f"{k:<10} | {n_fact:<18} | {t_str:<22} | Екстраполяція ({speed_perms_per_sec:.0f} перест/с)")

    lines.append("=" * 90)
    lines.append("✔ ВИСНОВОК: при довжині ключа k <= 8 повний перебір з дешифруванням триває до 0.5–1 с.")
    lines.append("Для k = 10 час становить близько 45–60 с, для k = 12 — близько кількох годин (екстраполяція),")
    lines.append("а для довжин k >= 15 простір n! робить атаку перебором абсолютно нереалізованою.")
    return "\n".join(lines)


# ----------------- КОНСОЛЬНЕ АВТО-ДЕМО -----------------
def run_auto_demo():
    print("=" * 80)
    print("      АВТОМАТИЧНА ДЕМОНСТРАЦІЯ: ЛАБОРАТОРНА РОБОТА № 3 (ШИФРИ ПЕРЕСТАВЛЯННЯ)")
    print("=" * 80)
    text = DEFAULT_TEXT
    print(f"Відкритий текст:\n«{text}»\n")

    # 1. Маршрутна перестановка
    cols = DEFAULT_COLS
    c_snake, orig_l_s, mat_s_before = encrypt_route_snake(text, cols)
    p_snake, mat_s_after = decrypt_route_snake(c_snake, cols, orig_l_s)
    assert p_snake == text, "Помилка дешифрування змійки!"
    print(f"1. Маршрутна перестановка («Змійка», {cols} стовпців):")
    print(f"   Шифротекст: «{c_snake}»")
    print("   Таблиця ДО зчитування (фрагмент перші 3 рядки):")
    print(format_matrix_display(mat_s_before[:3], [str(i) for i in range(cols)]))
    print("✔ [Маршрут «Змійка»]: успішно зашифровано та дешифровано.\n")

    # 2. Стовпцева перестановка
    kw1 = DEFAULT_KEYWORD
    c_col, orig_l_col, mat_c_before, mat_c_after = encrypt_columnar(text, kw1)
    p_col, _ = decrypt_columnar(c_col, kw1, orig_l_col)
    assert p_col == text, "Помилка дешифрування стовпцевої перестановки!"
    order = keyword_to_order(kw1)
    print(f"2. Стовпцева перестановка (ключ «{kw1}», порядок: {order}):")
    print(f"   Шифротекст: «{c_col}»")
    print("   Таблиця ДО перестановки (початкові стовпці):")
    print(format_matrix_display(mat_c_before[:2], list(kw1)))
    print("   Таблиця ПІСЛЯ перестановки (відсортовані стовпці):")
    print(format_matrix_display(mat_c_after[:2], [kw1[i] for i in order]))
    print("✔ [Стовпцева перестановка]: успішно зашифровано та дешифровано.\n")

    # 3. Подвійна перестановка
    kw2 = DEFAULT_KEYWORD2
    c_double, orig_l_d = encrypt_double_transposition(text, kw1, kw2)
    p_double = decrypt_double_transposition(c_double, kw1, kw2, orig_l_d)
    assert p_double == text, "Помилка дешифрування подвійної перестановки!"
    print(f"3. Подвійна перестановка («{kw1}» + «{kw2}»):")
    print(f"   Шифротекст: «{c_double}»")
    print("✔ [Подвійна перестановка]: успішно дешифровано.\n")

    # 4. Аналіз впливу довжини ключа
    print("4. АНАЛІЗ ВПЛИВУ ДОВЖИНИ КЛЮЧА (ПОВНИЙ ПЕРЕБІР ТА ЕКСТРАПОЛЯЦІЯ):")
    print(analyze_key_length_impact(text))
    print()

    # 5. Повна таблиця збереження частот
    print("5. ПОВНА ТАБЛИЦЯ ЧАСТОТ (33 ЛІТЕРИ, ІНВАРІАНТНІСТЬ):")
    ident, tbl_freq = compare_frequencies_full(text, c_col)
    assert ident, "Помилка: частоти відкритого тексту та шифротексту не ідентичні!"
    print(tbl_freq)
    print()

    # 6. Стрес-тест 500 випадкових текстів і ключів
    print("6. Стрес-тест: перевірка виправлення багу паддінгу на 500 випадкових текстах і ключах...")
    t_start = time.perf_counter()
    errors = 0
    for _ in range(500):
        t_len = random.randint(10, 220)
        rnd_text = "".join(random.choices(UKRAINIAN_ALPHABET + " .,-!?", k=t_len))
        k1 = "".join(random.choices(UKRAINIAN_ALPHABET, k=random.randint(2, 9)))
        k2 = "".join(random.choices(UKRAINIAN_ALPHABET, k=random.randint(2, 9)))
        c_r, orig_l_r = encrypt_double_transposition(rnd_text, k1, k2)
        p_r = decrypt_double_transposition(c_r, k1, k2, orig_l_r)
        if p_r != rnd_text:
            errors += 1
    dt_stress = time.perf_counter() - t_start
    print(f"   Час виконання: {dt_stress*1000:.1f} мс. Помилок: {errors}/500.")
    assert errors == 0, f"Виявлено {errors} помилок у стрес-тесті подвійної перестановки!"
    print("✔ [Assert перевірка]: 500/500 тестів пройдено без жодної помилки!")
    print("=" * 80)


# ----------------- ГРАФІЧНИЙ ІНТЕРФЕЙС (GUI TKINTER) -----------------
class TranspositionGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Лабораторна робота № 3: Шифри переставляння (НУ «Львівська політехніка»)")
        self.root.geometry("950x820")
        self.root.minsize(850, 700)

        self.last_ciphertext = ""

        main_frame = ttk.Frame(root, padding=8)
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            main_frame,
            text="Лабораторна робота № 3: Дослідження шифрів переставляння\n"
                 "Маршрутні («змійка», «спіраль»), стовпцеві та подвійні транспозиції",
            font=("Segoe UI", 11, "bold"),
            justify=tk.CENTER
        ).pack(pady=(0, 4))

        # 1. Відкритий текст
        tg = ttk.LabelFrame(main_frame, text=" 1. Вхідний відкритий текст ", padding=4)
        tg.pack(fill=tk.BOTH, expand=False, pady=2)
        self.text_input = scrolledtext.ScrolledText(tg, height=3, font=("Segoe UI", 9), wrap=tk.WORD)
        self.text_input.pack(fill=tk.BOTH, expand=True)
        self.text_input.insert(tk.END, DEFAULT_TEXT)

        # 2. Поле Шифротексту (G2)
        cg = ttk.LabelFrame(main_frame, text=" 2. Шифротекст (для дешифрування / аналізу) ", padding=4)
        cg.pack(fill=tk.BOTH, expand=False, pady=2)
        self.text_cipher = scrolledtext.ScrolledText(cg, height=3, font=("Segoe UI", 9), wrap=tk.WORD)
        self.text_cipher.pack(fill=tk.BOTH, expand=True)

        # 3. Налаштування ключів
        kg = ttk.LabelFrame(main_frame, text=" 3. Параметри шифрування ", padding=4)
        kg.pack(fill=tk.X, pady=2)

        row1 = ttk.Frame(kg)
        row1.pack(fill=tk.X, pady=2)
        ttk.Label(row1, text="Маршрут:").pack(side=tk.LEFT, padx=3)
        self.route_var = tk.StringVar(value="snake")
        ttk.Radiobutton(row1, text="«Змійка» по стовпцях", variable=self.route_var, value="snake").pack(side=tk.LEFT, padx=4)
        ttk.Radiobutton(row1, text="«Спіраль»", variable=self.route_var, value="spiral").pack(side=tk.LEFT, padx=4)

        ttk.Label(row1, text="Стовпців маршруту:").pack(side=tk.LEFT, padx=(12, 2))
        self.cols_var = tk.IntVar(value=DEFAULT_COLS)
        ttk.Spinbox(row1, from_=3, to=15, textvariable=self.cols_var, width=4).pack(side=tk.LEFT, padx=2)

        row2 = ttk.Frame(kg)
        row2.pack(fill=tk.X, pady=2)
        ttk.Label(row2, text="Ключове слово 1:").pack(side=tk.LEFT, padx=3)
        self.kw1_entry = ttk.Entry(row2, width=12)
        self.kw1_entry.insert(0, DEFAULT_KEYWORD)
        self.kw1_entry.pack(side=tk.LEFT, padx=2)

        ttk.Label(row2, text="Ключове слово 2:").pack(side=tk.LEFT, padx=(10, 2))
        self.kw2_entry = ttk.Entry(row2, width=12)
        self.kw2_entry.insert(0, DEFAULT_KEYWORD2)
        self.kw2_entry.pack(side=tk.LEFT, padx=2)

        # 4. Кнопки шифрування та дешифрування (G2)
        bg1 = ttk.Frame(main_frame)
        bg1.pack(fill=tk.X, pady=2)
        ttk.Button(bg1, text="🔒 Зашифр. маршрутну", command=self.handle_encrypt_route).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg1, text="🔒 Зашифр. стовпцеву", command=self.handle_encrypt_columnar).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg1, text="🔒 Зашифр. подвійну", command=self.handle_encrypt_double).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        bg2 = ttk.Frame(main_frame)
        bg2.pack(fill=tk.X, pady=2)
        ttk.Button(bg2, text="🔓 Дешифр. маршрутну", command=self.handle_decrypt_route).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg2, text="🔓 Дешифр. стовпцеву", command=self.handle_decrypt_columnar).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg2, text="🔓 Дешифр. подвійну", command=self.handle_decrypt_double).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        bg3 = ttk.Frame(main_frame)
        bg3.pack(fill=tk.X, pady=2)
        ttk.Button(bg3, text="▦ Таблиці ДО і ПІСЛЯ", command=self.handle_matrix_view).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg3, text="📈 Аналіз довжини ключа (n!)", command=self.handle_key_length_analysis).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg3, text="📊 Частоти (33 літери)", command=self.handle_frequencies).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg3, text="▶ Авто-демо", command=self.handle_auto_demo).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg3, text="🧹 Очистити", command=self.clear_output).pack(side=tk.LEFT, padx=2)

        # 5. Вивід
        og = ttk.LabelFrame(main_frame, text=" 4. Протокол операцій та таблиці перестановки ", padding=4)
        og.pack(fill=tk.BOTH, expand=True, pady=2)
        self.text_output = scrolledtext.ScrolledText(og, font=("Consolas", 8), wrap=tk.WORD, bg="#F9F9F9")
        self.text_output.pack(fill=tk.BOTH, expand=True)

        self.log("Програма готова. Оберіть дію, налаштуйте ключі або натисніть «▶ Авто-демо».\n")

    def log(self, msg: str):
        self.text_output.insert(tk.END, msg + "\n")
        self.text_output.see(tk.END)

    def clear_output(self):
        self.text_output.delete("1.0", tk.END)

    def get_plain_text(self) -> str:
        t = self.text_input.get("1.0", tk.END).strip()
        if not t:
            if messagebox:
                messagebox.showwarning("Помилка", "Введіть відкритий текст!")
            return ""
        return t

    def get_cipher_text(self) -> str:
        t = self.text_cipher.get("1.0", tk.END).strip()
        if not t and self.last_ciphertext:
            t = self.last_ciphertext
        return t

    def handle_encrypt_route(self):
        text = self.get_plain_text()
        if not text:
            return
        cols = self.cols_var.get()
        route = self.route_var.get()
        if route == "snake":
            c, orig_l, mat_b = encrypt_route_snake(text, cols)
            name = "Змійка"
        else:
            c, orig_l, mat_b = encrypt_route_spiral(text, cols)
            name = "Спіраль"

        self.last_ciphertext = c
        self.text_cipher.delete("1.0", tk.END)
        self.text_cipher.insert(tk.END, c)

        self.log("=" * 70)
        self.log(f"🔒 МАРШРУТНА ПЕРЕСТАНОВКА («{name}», {cols} стовпців):")
        self.log(f"Шифротекст:\n{c}")
        self.log("=" * 70)

    def handle_decrypt_route(self):
        c = self.get_cipher_text()
        if not c:
            if messagebox:
                messagebox.showwarning("Помилка", "Поле «Шифротекст» порожнє!")
            return
        cols = self.cols_var.get()
        route = self.route_var.get()
        orig_l = len(self.get_plain_text()) if self.get_plain_text() else len(c.replace(PADDING_CHAR, ""))
        if route == "snake":
            p, mat_after = decrypt_route_snake(c, cols, orig_l)
            name = "Змійка"
        else:
            p, mat_after = decrypt_route_spiral(c, cols, orig_l)
            name = "Спіраль"

        self.log("=" * 70)
        self.log(f"🔓 ДЕШИФРУВАННЯ МАРШРУТНОЇ ПЕРЕСТАНОВКИ («{name}»):")
        self.log(f"Відновлений текст:\n«{p}»")
        self.log("=" * 70)

    def handle_encrypt_columnar(self):
        text = self.get_plain_text()
        if not text:
            return
        kw = self.kw1_entry.get().strip().upper()
        if not kw:
            if messagebox:
                messagebox.showwarning("Помилка", "Введіть ключове слово!")
            return
        c, orig_l, mat_before, mat_after = encrypt_columnar(text, kw)
        self.last_ciphertext = c
        self.text_cipher.delete("1.0", tk.END)
        self.text_cipher.insert(tk.END, c)

        order = keyword_to_order(kw)
        self.log("=" * 70)
        self.log(f"🔒 СТОВПЦЕВА ПЕРЕСТАНОВКА (Ключ «{kw}»):")
        self.log(f"Порядок стовпців за укр. алфавітом: {order}")
        self.log(f"Шифротекст:\n{c}")
        self.log("=" * 70)

    def handle_decrypt_columnar(self):
        c = self.get_cipher_text()
        if not c:
            if messagebox:
                messagebox.showwarning("Помилка", "Поле «Шифротекст» порожнє!")
            return
        kw = self.kw1_entry.get().strip().upper()
        orig_l = len(self.get_plain_text()) if self.get_plain_text() else len(c.replace(PADDING_CHAR, ""))
        p, _ = decrypt_columnar(c, kw, orig_l)

        self.log("=" * 70)
        self.log(f"🔓 ДЕШИФРУВАННЯ СТОВПЦЕВОЇ ПЕРЕСТАНОВКИ (Ключ «{kw}»):")
        self.log(f"Відновлений текст:\n«{p}»")
        self.log("=" * 70)

    def handle_encrypt_double(self):
        text = self.get_plain_text()
        if not text:
            return
        kw1 = self.kw1_entry.get().strip().upper()
        kw2 = self.kw2_entry.get().strip().upper()
        c, _ = encrypt_double_transposition(text, kw1, kw2)
        self.last_ciphertext = c
        self.text_cipher.delete("1.0", tk.END)
        self.text_cipher.insert(tk.END, c)

        self.log("=" * 70)
        self.log(f"🔒 ПОДВІЙНА ПЕРЕСТАНОВКА («{kw1}» + «{kw2}»):")
        self.log(f"Подвійний шифротекст:\n{c}")
        self.log("=" * 70)

    def handle_decrypt_double(self):
        c = self.get_cipher_text()
        if not c:
            if messagebox:
                messagebox.showwarning("Помилка", "Поле «Шифротекст» порожнє!")
            return
        kw1 = self.kw1_entry.get().strip().upper()
        kw2 = self.kw2_entry.get().strip().upper()
        orig_l = len(self.get_plain_text()) if self.get_plain_text() else len(c.replace(PADDING_CHAR, ""))
        p = decrypt_double_transposition(c, kw1, kw2, orig_l)

        self.log("=" * 70)
        self.log(f"🔓 ДЕШИФРУВАННЯ ПОДВІЙНОЇ ПЕРЕСТАНОВКИ («{kw1}» + «{kw2}»):")
        self.log(f"Відновлений текст:\n«{p}»")
        self.log("=" * 70)

    def handle_matrix_view(self):
        text = self.get_plain_text()
        if not text:
            return
        kw = self.kw1_entry.get().strip().upper()
        cols = len(kw)
        c, _, mat_b, mat_a = encrypt_columnar(text[:45], kw)
        order = keyword_to_order(kw)

        self.log("=" * 65)
        self.log(f"▦ МАТРИЦЯ СТОВПЦЕВОЇ ПЕРЕСТАНОВКИ ДО І ПІСЛЯ (Ключ «{kw}»):")
        self.log("1. ТАБЛИЦЯ ДО ПЕРЕСТАНОВКИ (початковий запис по рядках):")
        self.log(format_matrix_display(mat_b, list(kw)))
        self.log("\n2. ТАБЛИЦЯ ПІСЛЯ ПЕРЕСТАНОВКИ (стовпці відсортовані за алфавітом):")
        self.log(format_matrix_display(mat_a, [kw[i] for i in order]))
        self.log("=" * 65)

    def handle_key_length_analysis(self):
        text = self.get_plain_text() or DEFAULT_TEXT
        self.log(analyze_key_length_impact(text))

    def handle_frequencies(self):
        text = self.get_plain_text() or DEFAULT_TEXT
        c = self.get_cipher_text()
        if not c:
            kw = self.kw1_entry.get().strip().upper()
            c, _, _, _ = encrypt_columnar(text, kw)
            self.last_ciphertext = c
            self.text_cipher.delete("1.0", tk.END)
            self.text_cipher.insert(tk.END, c)

        ident, tbl = compare_frequencies_full(text, c)
        self.log(tbl)

    def handle_auto_demo(self):
        self.clear_output()
        self.log("▶ Запуск повної автоматичної демонстрації ЛР № 3...")
        self.handle_encrypt_route()
        self.handle_decrypt_route()
        self.handle_encrypt_columnar()
        self.handle_decrypt_columnar()
        self.handle_encrypt_double()
        self.handle_decrypt_double()
        self.handle_matrix_view()
        self.handle_key_length_analysis()
        self.handle_frequencies()


def launch_gui():
    if not TKINTER_AVAILABLE:
        print("Помилка: бібліотека Tkinter недоступна у поточному середовищі Python.")
        print("Запустіть скрипт із прапорцем --demo для консольного тестування.")
        sys.exit(1)
    root = tk.Tk()
    app = TranspositionGUI(root)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("--demo", "-d", "demo"):
        sys.stdout.reconfigure(encoding="utf-8")
        run_auto_demo()
    else:
        launch_gui()
