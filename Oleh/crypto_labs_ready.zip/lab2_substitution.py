"""
Лабораторна робота № 2: Дослідження шифру простої заміни (моноалфавітний шифр)
Дисципліна: Захист інформації в інфокомунікаціях
Виконавець: студент 3-го курсу НУ «Львівська політехніка»

Графічний інтерфейс (GUI на Tkinter) + консольний режим (--demo).
Шифрування: C = f(P), Дешифрування: P = f⁻¹(C)
Криптоаналіз: повні частотні таблиці всіх 33 літер, гістограми █,
Hill-Climbing за біграмами шифротексту, ручна корекція, точність %.
"""

import sys
import time
import random
import math
import threading
from collections import Counter

# G1: Безпечні імпорти tkinter
try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, messagebox
    TKINTER_AVAILABLE = True
except ImportError:
    tk = None
    ttk = None
    scrolledtext = None
    messagebox = None
    TKINTER_AVAILABLE = False

# ----------------- КОНСТАНТИ ТА ЕТАЛОННІ ДАНІ -----------------
UKRAINIAN_ALPHABET = "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя"
ALPHABET_LEN = len(UKRAINIAN_ALPHABET)  # 33

# 4. REFERENCE_CORPUS >= 2500 літер звичайного українського тексту (не про криптографію)
REFERENCE_CORPUS = (
    "Україна — це велика держава у Східній і Центральній Європі з багатовіковою історією, самобутньою культурою "
    "та багатими народними традиціями. Її географічний ландшафт відзначається надзвичайним природним різноманіттям: "
    "від величних смерекових лісів та засніжених полонин Карпатських гір на заході до неозорих родючих степів "
    "на півдні, від мальовничих піщаних пагорбів та джерельних озер Полісся на півночі до сонячного морського "
    "узбережжя Чорного та Азовського морів. Головною водною артерією України є річка Дніпро — оспіваний у думах "
    "і козацьких піснях Славутич, що несе свої могутні води через усю територію країни до Чорноморського басейну. "
    "Дніпро має сакральне значення для української нації, адже вздовж його мальовничих круч упродовж багатьох "
    "тисячоліть творилася історія східнослов'янських народів. "
    "Столиця нашої держави — стародавнє місто Київ, засноване за переказами понад півтори тисячі років тому трьома "
    "братами Києм, Щеком, Хоривом та їхньою мудрою сестрою Либіддю. Київ був могутнім політичним, торговельним "
    "і духовним осередком Київської Русі — однієї з найвеличніших ранньосередньовічних держав Європи. У Києві височіє "
    "Софійський собор із неперевершеними мозаїками та фресками одинадцятого століття, Києво-Печерська лавра, Золоті "
    "ворота та стародавній ремісничий Поділ. У кожному куточку України збереглися унікальні архітектурні пам'ятки: "
    "кам'яні замки Поділля і Волині, старовинні дерев'яні храми Галичини та Закарпаття, козацькі фортифікації на Хортиці. "
    "Українська мова належить до слов'янської групи індоєвропейської мовної сім'ї. Вона вирізняється надзвичайною "
    "милозвучністю, евфонією, багатством фразеологізмів, гнучкістю граматичних форм та художньою виразністю. "
    "Протягом багатьох століть український народ створював багату усну народну творчість: героїчні думи, ліричні "
    "пісні, казки, прислів'я та приказки, в яких яскраво відобразилися високі моральні цінності, незламна воля "
    "до свободи, повага до рідної землі, працьовитість і щира гостинність. "
    "Видатний внесок у розвиток літературної мови та національної культури зробили Григорій Сковорода, Іван Котляревський, "
    "Тарас Шевченко, Леся Українка, Іван Франко, Михайло Коцюбинський та багато інших митців і мислителів. "
    "Сучасна Україна активно розвиває промисловість, аграрний сектор, фундаментальну науку та цифрові інформаційні "
    "технології. Українські вчені та інженери зробили значний внесок у розвиток світової космонавтики, авіабудування, "
    "електрозварювання, теоретичної кібернетики та програмування. Попри складні історичні випробування, народ завжди "
    "зберігав національну ідентичність і прагнення до побудови прогресивного, вільного та демократичного суспільства. "
    "Мистецька спадщина українського народу вражає своєю глибиною та самобутністю. Петриківський декоративний розпис, "
    "опішнянська кераміка, косівські мальовані кахлі та традиційні килими визнані унікальними надбаннями світової культури. "
    "Музичне мистецтво охоплює як старовинні кобзарські думи та хорову класику, так і сучасні напрями симфонічної музики. "
    "Українське театральне мистецтво, засноване корифеями українського побутового театру, продовжує збагачувати духовний світ громадян."
)

DEFAULT_DEMO_TEXT = (
    "Національний університет Львівська політехніка є одним із найстаріших вищих технічних "
    "навчальних закладів України та Східної Європи. Кафедра захисту інформації готує висококваліфікованих "
    "фахівців у галузі кібербезпеки та інфокомунікацій. У процесі вивчення курсу студенти детально "
    "досліджують як класичні моноалфавітні та поліалфавітні криптосистеми, так і сучасні симетричні "
    "стандарти блокового шифрування та асиметричні алгоритми з відкритим ключем. "
    "Шифр простої заміни демонструє фундаментальний принцип: великий розмір простору ключів сам по собі "
    "ще не гарантує криптографічної стійкості, якщо зберігаються статистичні закономірності відкритого "
    "повідомлення. Практичне освоєння методів криптоаналізу дозволяє майбутнім інженерам розробляти "
    "надійні протоколи обміну даними та успішно протидіяти загрозам перехоплення конфіденційної інформації."
)


# ----------------- БІГРАМНА ТА МОНОГРАМНА МОДЕЛЬ -----------------
def extract_words(t: str) -> list[str]:
    clean = ""
    for c in t.lower():
        clean += c if c in UKRAINIAN_ALPHABET else " "
    return [w for w in clean.split() if len(w) > 0]


def build_language_models(corpus: str):
    words = extract_words(corpus)
    clean_text = "".join(words)
    tot_letters = len(clean_text)

    # Монограми
    mono_counts = Counter(clean_text)
    mono_log = {ch: math.log10((mono_counts.get(ch, 0) + 0.1) / (tot_letters + 3.3)) for ch in UKRAINIAN_ALPHABET}

    # Біграми строго всередині слів
    bg_counts = Counter()
    for w in words:
        for i in range(len(w) - 1):
            bg_counts[(w[i], w[i+1])] += 1
    total_bigrams = sum(bg_counts.values())
    floor_val = 0.005
    denom = total_bigrams + floor_val * (ALPHABET_LEN ** 2)
    bg_log = {}
    for c1 in UKRAINIAN_ALPHABET:
        for c2 in UKRAINIAN_ALPHABET:
            cnt = bg_counts.get((c1, c2), 0)
            bg_log[(c1, c2)] = math.log10((cnt + floor_val) / denom)

    ref_freqs = {ch: mono_counts.get(ch, 0) / tot_letters for ch in UKRAINIAN_ALPHABET}
    return bg_log, mono_log, ref_freqs, clean_text


BIGRAM_LOG_PROBS, MONOGRAM_LOG_PROBS, REF_FREQUENCIES, CLEAN_CORPUS = build_language_models(REFERENCE_CORPUS)


# ----------------- ГЕНЕРАЦІЯ КЛЮЧІВ -----------------
def generate_random_substitution_key(no_fixed_points: bool = True) -> str:
    letters = list(UKRAINIAN_ALPHABET)
    while True:
        shuffled = letters.copy()
        random.shuffle(shuffled)
        if not no_fixed_points:
            return "".join(shuffled)
        if all(letters[i] != shuffled[i] for i in range(ALPHABET_LEN)):
            return "".join(shuffled)


def generate_keyword_substitution_key(keyword: str) -> str:
    used = set()
    key_chars = []
    for ch in keyword.lower():
        if ch in UKRAINIAN_ALPHABET and ch not in used:
            used.add(ch)
            key_chars.append(ch)
    for ch in UKRAINIAN_ALPHABET:
        if ch not in used:
            key_chars.append(ch)
    return "".join(key_chars)


# ----------------- ШИФРУВАННЯ ТА ДЕШИФРУВАННЯ -----------------
def encrypt_substitution(text: str, key_map_str: str) -> str:
    enc_dict = {UKRAINIAN_ALPHABET[i]: key_map_str[i] for i in range(ALPHABET_LEN)}
    result = []
    for ch in text:
        low = ch.lower()
        if low in enc_dict:
            c = enc_dict[low]
            result.append(c.upper() if ch.isupper() else c)
        else:
            result.append(ch)
    return "".join(result)


def decrypt_substitution(ciphertext: str, key_map_str: str) -> str:
    dec_dict = {key_map_str[i]: UKRAINIAN_ALPHABET[i] for i in range(ALPHABET_LEN)}
    result = []
    for ch in ciphertext:
        low = ch.lower()
        if low in dec_dict:
            p = dec_dict[low]
            result.append(p.upper() if ch.isupper() else p)
        else:
            result.append(ch)
    return "".join(result)


def compute_frequencies(text: str):
    letters = [ch.lower() for ch in text if ch.lower() in UKRAINIAN_ALPHABET]
    n_total = len(letters)
    if n_total == 0:
        return {ch: 0 for ch in UKRAINIAN_ALPHABET}, {ch: 0.0 for ch in UKRAINIAN_ALPHABET}, 0
    counts = Counter(letters)
    freq_dict = {ch: counts.get(ch, 0) / n_total for ch in UKRAINIAN_ALPHABET}
    return counts, freq_dict, n_total


def initial_frequency_guess(ciphertext: str) -> dict[str, str]:
    """Створює відображення {cipher_char: plain_char} за рангами монограм."""
    c_letters = [ch.lower() for ch in ciphertext if ch.lower() in UKRAINIAN_ALPHABET]
    c_counts = Counter(c_letters)
    c_ranked = [x[0] for x in c_counts.most_common()]
    for ch in UKRAINIAN_ALPHABET:
        if ch not in c_ranked:
            c_ranked.append(ch)

    corp_counts = Counter(CLEAN_CORPUS)
    ref_ranked = [x[0] for x in corp_counts.most_common()]
    for ch in UKRAINIAN_ALPHABET:
        if ch not in ref_ranked:
            ref_ranked.append(ch)

    dec_map = {c_ranked[i]: ref_ranked[i] for i in range(ALPHABET_LEN)}
    return dec_map


def apply_decryption_map(ciphertext: str, dec_map: dict[str, str]) -> str:
    result = []
    for ch in ciphertext:
        low = ch.lower()
        if low in dec_map:
            p = dec_map[low]
            result.append(p.upper() if ch.isupper() else p)
        else:
            result.append(ch)
    return "".join(result)


# ----------------- ШВИДКИЙ HILL-CLIMBING ЗА БІГРАМАМИ ШИФРОТЕКСТУ -----------------
def hill_climbing_attack(
    ciphertext: str,
    restarts: int = 25,
    steps_per_restart: int = 6000
) -> tuple[dict[str, str], float]:
    """
    Оптимізований Hill-Climbing:
    - Counter біграм шифротексту рахується ОДИН раз.
    - Оцінка розраховується як SUM cnt * log P(dec_map[c1], dec_map[c2]) без дешифрування тексту.
    - >= 25 рестартів (1-й зі стартового частотного зіставлення, решта — незалежні випадкові перестановки).
    - >= 6000 обмінів на рестарт.
    - 2-opt детермінований спуск для дошліфування.
    """
    def extract_words(t):
        clean = ""
        for c in t.lower():
            clean += c if c in UKRAINIAN_ALPHABET else " "
        return [w for w in clean.split() if len(w) > 0]

    ct_words = extract_words(ciphertext)
    ct_bg = Counter()
    for w in ct_words:
        for i in range(len(w) - 1):
            ct_bg[(w[i], w[i+1])] += 1
    ct_items = list(ct_bg.items())

    ct_letters = Counter("".join(ct_words))
    c_ranked = [x[0] for x in ct_letters.most_common()] + [c for c in UKRAINIAN_ALPHABET if c not in ct_letters]
    corp_letters = Counter(CLEAN_CORPUS)
    ref_ranked = [x[0] for x in corp_letters.most_common()] + [c for c in UKRAINIAN_ALPHABET if c not in corp_letters]
    init_dec_map = {c_ranked[i]: ref_ranked[i] for i in range(ALPHABET_LEN)}

    def score_map(m):
        return sum(cnt * BIGRAM_LOG_PROBS[(m[c1], m[c2])] for (c1, c2), cnt in ct_items)

    all_cipher_chars = list(UKRAINIAN_ALPHABET)
    best_overall_map = init_dec_map.copy()
    best_overall_score = score_map(best_overall_map)

    for r in range(restarts):
        if r == 0:
            cur_map = init_dec_map.copy()
        else:
            sh = list(UKRAINIAN_ALPHABET)
            random.shuffle(sh)
            cur_map = {all_cipher_chars[i]: sh[i] for i in range(ALPHABET_LEN)}

        cur_score = score_map(cur_map)

        for _ in range(steps_per_restart):
            k1, k2 = random.sample(all_cipher_chars, 2)
            cur_map[k1], cur_map[k2] = cur_map[k2], cur_map[k1]
            cand_score = score_map(cur_map)
            if cand_score >= cur_score:
                cur_score = cand_score
            else:
                cur_map[k1], cur_map[k2] = cur_map[k2], cur_map[k1]

        # 2-opt детермінована перевірка всіх пар для виходу з локальних плато
        improved = True
        while improved:
            improved = False
            for i in range(ALPHABET_LEN):
                for j in range(i + 1, ALPHABET_LEN):
                    k1, k2 = all_cipher_chars[i], all_cipher_chars[j]
                    cur_map[k1], cur_map[k2] = cur_map[k2], cur_map[k1]
                    s = score_map(cur_map)
                    if s > cur_score:
                        cur_score = s
                        improved = True
                        break
                    else:
                        cur_map[k1], cur_map[k2] = cur_map[k2], cur_map[k1]
                if improved:
                    break

        if cur_score > best_overall_score:
            best_overall_score = cur_score
            best_overall_map = cur_map.copy()

    return best_overall_map, best_overall_score


def calculate_accuracy(original_text: str, recovered_text: str) -> float:
    orig_letters = [ch.lower() for ch in original_text if ch.lower() in UKRAINIAN_ALPHABET]
    rec_letters = [ch.lower() for ch in recovered_text if ch.lower() in UKRAINIAN_ALPHABET]
    if not orig_letters or len(orig_letters) != len(rec_letters):
        return 0.0
    correct = sum(1 for o, r in zip(orig_letters, rec_letters) if o == r)
    return (correct / len(orig_letters)) * 100.0


# ----------------- ФОРМАТУВАННЯ ПОВНОЇ ЧАСТОТНОЇ ТАБЛИЦІ (УСІ 33 ЛІТЕРИ) -----------------
def format_full_frequency_table(plain_text: str, cipher_text: str) -> str:
    p_counts, p_freqs, p_tot = compute_frequencies(plain_text)
    c_counts, c_freqs, c_tot = compute_frequencies(cipher_text)

    # 4. Сортування колонки відкритого тексту за власною частотою (за спаданням)
    # та колонки шифротексту за власною частотою (за спаданням) окремо,
    # щоб було наочно видно відповідність за частотним рангом.
    p_sorted = sorted(UKRAINIAN_ALPHABET, key=lambda ch: (p_freqs[ch], p_counts[ch]), reverse=True)
    c_sorted = sorted(UKRAINIAN_ALPHABET, key=lambda ch: (c_freqs[ch], c_counts[ch]), reverse=True)

    lines = []
    lines.append("=" * 90)
    lines.append(f"{'Ранг':<4} | {'Літера P':<8} | {'К-сть P':<7} | {'% P':<6} | {'Літера C':<8} | {'К-сть C':<7} | {'% C':<6} | {'Еталон %':<8} | Гістограма P █")
    lines.append("-" * 90)

    for idx in range(ALPHABET_LEN):
        p_ch = p_sorted[idx]
        p_c = p_counts[p_ch]
        p_pct = p_freqs[p_ch] * 100
        ref_pct = REF_FREQUENCIES.get(p_ch, 0.0) * 100

        c_ch = c_sorted[idx]
        c_c = c_counts[c_ch]
        c_pct = c_freqs[c_ch] * 100

        bar = "█" * int(round(p_pct * 1.5))
        lines.append(
            f"{idx+1:<4} | {p_ch.upper():<8} | {p_c:<7} | {p_pct:>5.1f}% | "
            f"{c_ch.upper():<8} | {c_c:<7} | {c_pct:>5.1f}% | {ref_pct:>7.2f}% | {bar}"
        )
    lines.append("=" * 90)
    return "\n".join(lines)


# ----------------- КОНСОЛЬНЕ АВТО-ДЕМО -----------------
def run_auto_demo():
    print("=" * 82)
    print("      АВТОМАТИЧНА ДЕМОНСТРАЦІЯ: ЛАБОРАТОРНА РОБОТА № 2 (ШИФР ПРОСТОЇ ЗАМІНИ)")
    print("=" * 82)
    text = DEFAULT_DEMO_TEXT

    # 4. Перевірка розміру корпусу
    clean_corp = "".join(ch for ch in REFERENCE_CORPUS if ch.lower() in UKRAINIAN_ALPHABET)
    print(f"1. Довідковий корпус (REFERENCE_CORPUS): {len(clean_corp)} літер (>= 2500: ДОТРИМАНО).")
    assert len(clean_corp) >= 2500, "REFERENCE_CORPUS має містити щонайменше 2500 літер!"
    print(f"   Відкритий текст: {len(text)} символів (>= 800: ДОТРИМАНО).")

    # 5. Порівняння простору ключів 33! vs 33 (Цезар)
    f33 = math.factorial(33)
    ratio = f33 // 33
    print(f"2. Простір ключів 33! = {f33} (≈ {f33:.3e} варіантів).")
    print(f"   Порівняння з шифром Цезаря (33 ключі): у {ratio:.3e} разів більше (32! разів).")

    # Демонстраційний ключ (явне позначення seed=42):
    random.seed(42)
    key = generate_random_substitution_key(no_fixed_points=True)
    print(f"   Згенерований ключ заміни (seed=42, C для кожного P):")
    print(f"   P: {' '.join(UKRAINIAN_ALPHABET)}")
    print(f"   C: {' '.join(key)}")

    ciphertext = encrypt_substitution(text, key)
    print(f"\n3. Шифротекст (перші 120 символів):\n   «{ciphertext[:120]}...»")

    decrypted = decrypt_substitution(ciphertext, key)
    assert decrypted == text, "Помилка: дешифрування не повернуло оригінальний текст!"
    print("✔ [Вбудована перевірка]: Дешифрування правильним ключем повернуло 100% оригінал.")

    # 1. Повна частотна таблиця всіх 33 літер (рангове зіставлення)
    print("\n4. ПОВНА ЧАСТОТНА ТАБЛИЦЯ ВСІХ 33 ЛІТЕР (рангове зіставлення окремо P та C):")
    print(format_full_frequency_table(text, ciphertext))

    # 2. Результат чистого зіставлення за рангом частот
    init_map = initial_frequency_guess(ciphertext)
    init_rec = apply_decryption_map(ciphertext, init_map)
    init_acc = calculate_accuracy(text, init_rec)
    print(f"\n5. Чисте зіставлення за рангом частот (монограми): точність = {init_acc:.1f}%.")
    print(f"   Зразок тексту після монограм:\n   «{init_rec[:100]}...»")

    # 3 додаткові запуски з іншими seed для наочного показу розкиду
    print("\n6. Демонстрація розкиду результатів на 3 додаткових seed (seed=201, 202, 203):")
    for s_demo in (201, 202, 203):
        random.seed(s_demo)
        k_demo = generate_random_substitution_key(no_fixed_points=True)
        ct_demo = encrypt_substitution(text, k_demo)
        m_demo, _ = hill_climbing_attack(ct_demo, restarts=25, steps_per_restart=6000)
        acc_demo = calculate_accuracy(text, apply_decryption_map(ct_demo, m_demo))
        print(f"   • seed={s_demo}: точність = {acc_demo:5.1f}%")

    # 2. Критерій приймання: на 12 різних seed (100–111) середня точність >= 90% і не менше 10 із 12 >= 90%
    print("\n7. СЕРІЯ ТЕСТІВ: Hill-Climbing на 12 різних seed (100–111):")
    print("   (restarts=25, steps=6000, 1-й старт — частотне зіставлення, решта — випадкові)")
    accuracies = []
    t_start = time.perf_counter()
    for s in range(100, 112):
        random.seed(s)
        test_key = generate_random_substitution_key(no_fixed_points=True)
        ct_test = encrypt_substitution(text, test_key)
        best_d_map, _ = hill_climbing_attack(ct_test, restarts=25, steps_per_restart=6000)
        rec_test = apply_decryption_map(ct_test, best_d_map)
        acc = calculate_accuracy(text, rec_test)
        accuracies.append(acc)
        status = "✔ >=90%" if acc >= 90.0 else "✖ <90%"
        print(f"   • Seed {s:3d} (тест {s-99:2d}/12): точність = {acc:5.1f}%  [{status}]")

    total_time = time.perf_counter() - t_start
    avg_acc = sum(accuracies) / len(accuracies)
    min_acc = min(accuracies)
    max_acc = max(accuracies)
    count_90 = sum(1 for a in accuracies if a >= 90.0)

    print(f"\nСТАТИСТИКА HILL-CLIMBING (12 seed 100–111, час: {total_time:.1f} с):")
    print(f"   Середня точність : {avg_acc:.2f}% (вимога >= 90%: {'✔ ДОТРИМАНО' if avg_acc >= 90.0 else '✖ НЕ ДОСЯГНУТО'})")
    print(f"   Мінімальна       : {min_acc:.1f}%")
    print(f"   Максимальна      : {max_acc:.1f}%")
    print(f"   Успішних (>= 90%): {count_90}/12 (вимога >= 10/12: {'✔ ДОТРИМАНО' if count_90 >= 10 else '✖ НЕ ДОСЯГНУТО'})")

    assert avg_acc >= 90.0, f"Середня точність {avg_acc:.2f}% повинна бути >= 90%!"
    assert count_90 >= 10, f"Кількість запусків з точністю >= 90% ({count_90}/12) повинна бути >= 10!"
    print("✔ [Assert перевірка]: Критерій успішності на 12 seed (середня >= 90%, >=10/12) виконано!")
    print("=" * 82)


# ----------------- ГРАФІЧНИЙ ІНТЕРФЕЙС (GUI TKINTER) -----------------
class SubstitutionGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Лабораторна робота № 2: Шифр простої заміни (НУ «Львівська політехніка»)")
        self.root.geometry("940x800")
        self.root.minsize(850, 700)

        self.current_key = generate_random_substitution_key(no_fixed_points=True)
        self.last_ciphertext = ""
        self.manual_d_map = {ch: ch for ch in UKRAINIAN_ALPHABET}

        main_frame = ttk.Frame(root, padding=8)
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            main_frame,
            text="Лабораторна робота № 2: Дослідження моноалфавітного шифру простої заміни\n"
                 "C = f(P), P = f⁻¹(C)  |  Простір ключів: 33! ≈ 8.68 × 10³⁶  (Цезар: 33)",
            font=("Segoe UI", 11, "bold"),
            justify=tk.CENTER
        ).pack(pady=(0, 4))

        # 1. Відкритий текст
        text_group = ttk.LabelFrame(main_frame, text=" 1. Відкритий текст (рекомендовано >= 800 символів) ", padding=4)
        text_group.pack(fill=tk.BOTH, expand=False, pady=2)

        self.text_input = scrolledtext.ScrolledText(text_group, height=3, font=("Segoe UI", 9), wrap=tk.WORD)
        self.text_input.pack(fill=tk.BOTH, expand=True)
        self.text_input.insert(tk.END, DEFAULT_DEMO_TEXT)

        # 2. Поле Шифротексту (G2)
        cipher_group = ttk.LabelFrame(main_frame, text=" 2. Шифротекст (для дешифрування / аналізу) ", padding=4)
        cipher_group.pack(fill=tk.BOTH, expand=False, pady=2)

        self.text_cipher = scrolledtext.ScrolledText(cipher_group, height=3, font=("Segoe UI", 9), wrap=tk.WORD)
        self.text_cipher.pack(fill=tk.BOTH, expand=True)

        # 3. Ключ заміни
        key_group = ttk.LabelFrame(main_frame, text=" 3. Налаштування таблиці заміни (Ключ) ", padding=4)
        key_group.pack(fill=tk.X, pady=2)

        k_row1 = ttk.Frame(key_group)
        k_row1.pack(fill=tk.X, pady=2)
        ttk.Button(k_row1, text="🎲 Згенерувати випадкову таблицю (без нерухомих точок)", command=self.handle_gen_random_key).pack(side=tk.LEFT, padx=3)

        ttk.Label(k_row1, text="Гасло:").pack(side=tk.LEFT, padx=(12, 2))
        self.kw_entry = ttk.Entry(k_row1, width=12)
        self.kw_entry.insert(0, "КАФЕДРА")
        self.kw_entry.pack(side=tk.LEFT, padx=2)
        ttk.Button(k_row1, text="Зі слова", command=self.handle_keyword_key).pack(side=tk.LEFT, padx=3)

        self.key_display_var = tk.StringVar(value="C: " + " ".join(self.current_key))
        ttk.Label(key_group, text="P: " + " ".join(UKRAINIAN_ALPHABET), font=("Consolas", 8)).pack(anchor=tk.W)
        ttk.Label(key_group, textvariable=self.key_display_var, font=("Consolas", 8, "bold"), foreground="#003366").pack(anchor=tk.W)

        # 4. Кнопки операцій
        ops_frame = ttk.Frame(main_frame)
        ops_frame.pack(fill=tk.X, pady=3)

        ttk.Button(ops_frame, text="🔒 Зашифрувати", command=self.handle_encrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(ops_frame, text="🔓 Дешифрувати", command=self.handle_decrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(ops_frame, text="📊 Частотна таблиця 33 літер", command=self.handle_frequencies).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(ops_frame, text="🧠 Hill-Climbing (біграми)", command=self.handle_hill_climbing).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(ops_frame, text="▶ Авто-демо", command=self.handle_auto_demo).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        # 5. Ручне уточнення замін
        manual_frame = ttk.LabelFrame(main_frame, text=" 4. Ручне уточнення замін літер ", padding=4)
        manual_frame.pack(fill=tk.X, pady=2)

        ttk.Label(manual_frame, text="Шифролітера:").pack(side=tk.LEFT, padx=3)
        self.char_from_entry = ttk.Entry(manual_frame, width=3, font=("Segoe UI", 10))
        self.char_from_entry.pack(side=tk.LEFT, padx=2)
        ttk.Label(manual_frame, text="→ Замінити на відкриту:").pack(side=tk.LEFT, padx=3)
        self.char_to_entry = ttk.Entry(manual_frame, width=3, font=("Segoe UI", 10))
        self.char_to_entry.pack(side=tk.LEFT, padx=2)
        ttk.Button(manual_frame, text="Застосувати заміну", command=self.handle_manual_swap).pack(side=tk.LEFT, padx=6)
        ttk.Button(manual_frame, text="🧹 Очистити журнал", command=self.clear_output).pack(side=tk.RIGHT, padx=3)

        # 6. Результати
        out_group = ttk.LabelFrame(main_frame, text=" 5. Журнал аналізу та відновлений текст ", padding=4)
        out_group.pack(fill=tk.BOTH, expand=True, pady=2)

        self.text_output = scrolledtext.ScrolledText(out_group, font=("Consolas", 8), wrap=tk.WORD, bg="#F9F9F9")
        self.text_output.pack(fill=tk.BOTH, expand=True)

        self.log("Програма готова до роботи. Введіть текст, налаштуйте ключ або натисніть «▶ Авто-демо».\n")

    def log(self, message: str):
        self.text_output.insert(tk.END, message + "\n")
        self.text_output.see(tk.END)

    def clear_output(self):
        self.text_output.delete("1.0", tk.END)

    def update_key_display(self):
        self.key_display_var.set("C: " + " ".join(self.current_key))

    def handle_gen_random_key(self):
        self.current_key = generate_random_substitution_key(no_fixed_points=True)
        self.update_key_display()
        self.log(f"🎲 Згенеровано новий ключ заміни (без нерухомих точок):\nC: {self.current_key}")

    def handle_keyword_key(self):
        kw = self.kw_entry.get().strip()
        if not kw:
            if messagebox:
                messagebox.showwarning("Помилка", "Введіть ключове слово!")
            return
        self.current_key = generate_keyword_substitution_key(kw)
        self.update_key_display()
        self.log(f"✔ Сформовано ключ на базі гасла «{kw}»:\nC: {self.current_key}")

    def get_plain_text(self) -> str:
        t = self.text_input.get("1.0", tk.END).strip()
        if not t:
            if messagebox:
                messagebox.showwarning("Помилка", "Введіть відкритий текст!")
            return ""
        return t

    def get_cipher_text(self) -> str:
        """G2: Отримує шифротекст із поля 'Шифротекст', або бере результат останнього шифрування."""
        t = self.text_cipher.get("1.0", tk.END).strip()
        if not t and self.last_ciphertext:
            t = self.last_ciphertext
        return t

    def handle_encrypt(self):
        text = self.get_plain_text()
        if not text:
            return
        c = encrypt_substitution(text, self.current_key)
        self.last_ciphertext = c
        self.text_cipher.delete("1.0", tk.END)
        self.text_cipher.insert(tk.END, c)

        self.log("=" * 70)
        self.log("🔒 ШИФРУВАННЯ ТЕКСТУ ЗА ТАБЛИЦЕЮ ЗАМІНИ:")
        self.log(f"Шифротекст (перші 150 симв.):\n«{c[:150]}...»")
        p = decrypt_substitution(c, self.current_key)
        if p == text:
            self.log("✔ [Вбудована перевірка]: Дешифрування повернуло 100% оригінал.")
        self.log("=" * 70)

    def handle_decrypt(self):
        """G2: Розшифровує шифротекст із спеціального поля без повторного шифрування!"""
        c = self.get_cipher_text()
        if not c:
            if messagebox:
                messagebox.showwarning("Помилка", "Поле «Шифротекст» порожнє! Введіть або зашифруйте текст.")
            return

        p = decrypt_substitution(c, self.current_key)
        self.log("=" * 70)
        self.log("🔓 ДЕШИФРУВАННЯ ШИФРОТЕКСТУ ЗА ЗВОРОТНОЮ ТАБЛИЦЕЮ:")
        self.log(f"Шифротекст для дешифрування (перші 120 симв.):\n«{c[:120]}...»")
        self.log(f"Відновлений відкритий текст (перші 150 симв.):\n«{p[:150]}...»")
        self.log("=" * 70)

    def handle_frequencies(self):
        text = self.get_plain_text()
        c = self.get_cipher_text()
        if not text:
            return
        if not c:
            c = encrypt_substitution(text, self.current_key)
            self.last_ciphertext = c
            self.text_cipher.delete("1.0", tk.END)
            self.text_cipher.insert(tk.END, c)

        self.log(format_full_frequency_table(text, c))

    def handle_hill_climbing(self):
        c = self.get_cipher_text()
        text = self.get_plain_text()
        if not c:
            if not text:
                return
            c = encrypt_substitution(text, self.current_key)
            self.last_ciphertext = c
            self.text_cipher.delete("1.0", tk.END)
            self.text_cipher.insert(tk.END, c)

        self.log("=" * 75)
        self.log("🧠 ЗАПУСК КРИПТОАНАЛІЗУ: ЧАСТОТНІ РАНГИ ТА HILL-CLIMBING ЗА БІГРАМАМИ...")
        self.log("   (Обчислення виконуються у фоновому потоці, вікно залишається чуйним)")

        def worker():
            # 1. Початкове зіставлення за рангом монограм
            init_map = initial_frequency_guess(c)
            init_rec = apply_decryption_map(c, init_map)
            if text:
                init_acc = calculate_accuracy(text, init_rec)
                self.root.after(0, lambda: self.log(f"1. Чисте зіставлення за рангами монограм: точність = {init_acc:.1f}%."))
            else:
                self.root.after(0, lambda: self.log("1. Виконано початкове зіставлення за рангами монограм."))

            # 2. Hill-Climbing
            t0 = time.perf_counter()
            best_d_map, _ = hill_climbing_attack(c, restarts=25, steps_per_restart=6000)
            dt = time.perf_counter() - t0

            def on_complete():
                self.manual_d_map = best_d_map.copy()
                rec_text = apply_decryption_map(c, best_d_map)
                self.log(f"2. Hill-Climbing оптимізовано за {dt:.2f} с ({25} рестартів по {6000} кроків).")
                if text:
                    acc = calculate_accuracy(text, rec_text)
                    self.log(f"   • Точність розпізнавання літер: {acc:.1f}% (покращення: +{acc - init_acc:.1f}%)")
                self.log(f"   • Зразок відновленого тексту:\n«{rec_text[:180]}...»")
                self.log("=" * 75)

            self.root.after(0, on_complete)

        threading.Thread(target=worker, daemon=True).start()

    def handle_manual_swap(self):
        c_from = self.char_from_entry.get().strip().lower()
        c_to = self.char_to_entry.get().strip().lower()
        if c_from not in UKRAINIAN_ALPHABET or c_to not in UKRAINIAN_ALPHABET:
            if messagebox:
                messagebox.showwarning("Помилка", "Введіть коректні українські літери!")
            return

        old_val = self.manual_d_map.get(c_from, c_from)
        for k, v in self.manual_d_map.items():
            if v == c_to and k != c_from:
                self.manual_d_map[k] = old_val
                break
        self.manual_d_map[c_from] = c_to

        c = self.get_cipher_text()
        text = self.get_plain_text()
        if c:
            upd_text = apply_decryption_map(c, self.manual_d_map)
            acc_str = f"Нова точність: {calculate_accuracy(text, upd_text):.1f}%" if text else ""
            self.log(f"✔ Ручна заміна: шифролітера '{c_from}' -> '{c_to}'. {acc_str}")
            self.log(f"Текст:\n«{upd_text[:140]}...»")

    def handle_auto_demo(self):
        self.clear_output()
        self.log("▶ Запуск автоматичної демонстрації ЛР № 2...")
        self.handle_encrypt()
        self.handle_frequencies()
        self.handle_hill_climbing()


def launch_gui():
    if not TKINTER_AVAILABLE:
        print("Помилка: бібліотека Tkinter недоступна у поточному середовищі Python.")
        print("Запустіть скрипт із прапорцем --demo для консольного тестування.")
        sys.exit(1)
    root = tk.Tk()
    app = SubstitutionGUI(root)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("--demo", "-d", "demo"):
        sys.stdout.reconfigure(encoding="utf-8")
        run_auto_demo()
    else:
        launch_gui()
