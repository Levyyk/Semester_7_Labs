"""
Лабораторна робота № 4: Дослідження поліалфавітного шифру (шифр Віженера)
Дисципліна: Захист інформації в інфокомунікаціях
Виконавець: студент 3-го курсу НУ «Львівська політехніка»

Графічний інтерфейс (GUI на Tkinter) + консольний режим (--demo).
Шифрування: C_i = (P_i + K_i) mod 33, Дешифрування: P_i = (C_i - K_i) mod 33
Сліпий криптоаналіз: індекс збігу IC (тест Фрідмана), метод Касіскі, стовпцевий хі-квадрат.
"""

import sys
import re
import math
import random
from collections import Counter

# Безпечний імпорт Tkinter (G1)
try:
    import tkinter as tk
    from tkinter import ttk, scrolledtext, messagebox
    HAS_TKINTER = True
except ImportError:
    HAS_TKINTER = False

# ----------------- КОНСТАНТИ ТА ЕТАЛОННІ ДАНІ -----------------
UKRAINIAN_ALPHABET = "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя"
ALPHABET_LEN = len(UKRAINIAN_ALPHABET)  # 33

IC_UKRAINIAN_EXPECTED = 0.056
IC_RANDOM_EXPECTED = 1.0 / ALPHABET_LEN  # ≈ 0.0303

UKRAINIAN_FREQUENCIES = {
    'о': 0.0928, 'а': 0.0834, 'н': 0.0654, 'і': 0.0623, 'и': 0.0612,
    'т': 0.0560, 'в': 0.0523, 'р': 0.0475, 'е': 0.0463, 'с': 0.0414,
    'к': 0.0401, 'л': 0.0371, 'д': 0.0355, 'у': 0.0326, 'м': 0.0311,
    'п': 0.0284, 'я': 0.0216, 'з': 0.0210, 'ь': 0.0183, 'б': 0.0170,
    'г': 0.0160, 'ч': 0.0139, 'й': 0.0124, 'х': 0.0117, 'ц': 0.0102,
    'ж': 0.0091, 'ш': 0.0089, 'ю': 0.0070, 'ї': 0.0062, 'є': 0.0055,
    'щ': 0.0049, 'ф': 0.0028, 'ґ': 0.0001
}

DEFAULT_TEXT = (
    "Поліалфавітні шифри були створені з метою подолання головної слабкості "
    "моноалфавітних систем, а саме незмінності статистичного розподілу частот появи окремих літер. "
    "Шифр Віженера є найбільш відомим історичним прикладом поліалфавітної криптосистеми. "
    "У ньому шифрування здійснюється послідовністю простих зсувів Цезаря, де кожен наступний "
    "зсув визначається черговою літерою секретного ключового слова. Завдяки циклічному "
    "повторенню ключа одна й та сама літера відкритого тексту залежно від своєї позиції може "
    "переходити в різні літери шифротексту, і навпаки, однакові символи криптограми можуть "
    "відповідати абсолютно різним відкритим символам. Проте періодичність накладання ключа "
    "створює внутрішню структуру, яку можна розкрити комбінацією методу Касіскі та обчислення "
    "індексу збігу. Якщо криптоаналітик точно визначає довжину ключа, задача зводиться до "
    "незалежного розкриття кількох шифрів Цезаря за допомогою частотного криптоаналізу."
)
DEFAULT_KEY = "ПОЛІТЕХ"

SHORT_LIMITATION_TEXT = (
    "Поліалфавітні шифри створені з метою подолання головної слабкості моноалфавітних "
    "систем, а саме збереження статистичного розподілу літер мови."
)


# ----------------- БАЗОВІ ФУНКЦІЇ -----------------
def clean_key(key: str) -> str:
    """Витягує лише символи української абетки з ключа у нижньому регістрі."""
    return "".join(ch.lower() for ch in key if ch.lower() in UKRAINIAN_ALPHABET)


def encrypt_vigenere(text: str, key: str) -> str:
    """Шифрування Віженера: C_i = (P_i + K_{i mod d}) mod 33."""
    k_clean = clean_key(key)
    if not k_clean:
        raise ValueError("Ключ повинен містити хоча б одну українську літеру!")
    k_len = len(k_clean)
    k_shifts = [UKRAINIAN_ALPHABET.index(c) for c in k_clean]
    result = []
    k_idx = 0
    for ch in text:
        low = ch.lower()
        if low in UKRAINIAN_ALPHABET:
            p_val = UKRAINIAN_ALPHABET.index(low)
            shift = k_shifts[k_idx % k_len]
            c_val = (p_val + shift) % ALPHABET_LEN
            out_ch = UKRAINIAN_ALPHABET[c_val]
            result.append(out_ch.upper() if ch.isupper() else out_ch)
            k_idx += 1
        else:
            result.append(ch)
    return "".join(result)


def decrypt_vigenere(ciphertext: str, key: str) -> str:
    """Дешифрування Віженера: P_i = (C_i - K_{i mod d}) mod 33."""
    k_clean = clean_key(key)
    if not k_clean:
        raise ValueError("Ключ повинен містити українські літери!")
    k_len = len(k_clean)
    k_shifts = [UKRAINIAN_ALPHABET.index(c) for c in k_clean]
    result = []
    k_idx = 0
    for ch in ciphertext:
        low = ch.lower()
        if low in UKRAINIAN_ALPHABET:
            c_val = UKRAINIAN_ALPHABET.index(low)
            shift = k_shifts[k_idx % k_len]
            p_val = (c_val - shift) % ALPHABET_LEN
            out_ch = UKRAINIAN_ALPHABET[p_val]
            result.append(out_ch.upper() if ch.isupper() else out_ch)
            k_idx += 1
        else:
            result.append(ch)
    return "".join(result)


def calculate_index_of_coincidence(text: str) -> float:
    """Обчислення індексу збігу IC = sum(f_i * (f_i - 1)) / (N * (N - 1))."""
    letters = [ch.lower() for ch in text if ch.lower() in UKRAINIAN_ALPHABET]
    n = len(letters)
    if n <= 1:
        return 0.0
    counts = Counter(letters)
    return sum(cnt * (cnt - 1) for cnt in counts.values()) / (n * (n - 1))


def calculate_average_ic_for_period(ciphertext: str, period_d: int) -> float:
    """Обчислює середній індекс збігу по period_d стовпцях шифротексту."""
    letters = [ch.lower() for ch in ciphertext if ch.lower() in UKRAINIAN_ALPHABET]
    if len(letters) < period_d * 2:
        return 0.0
    cosets = [[] for _ in range(period_d)]
    for i, ch in enumerate(letters):
        cosets[i % period_d].append(ch)
    return sum(calculate_index_of_coincidence("".join(c)) for c in cosets) / len(cosets)


def count_repeated_trigrams(text: str) -> int:
    """Підраховує кількість повторюваних триграм у тексті."""
    letters = [ch.lower() for ch in text if ch.lower() in UKRAINIAN_ALPHABET]
    trigrams = Counter("".join(letters[i:i+3]) for i in range(len(letters) - 2))
    return sum(1 for cnt in trigrams.values() if cnt > 1)


def kasiski_examination(ciphertext: str, min_len: int = 3) -> dict:
    """Аналіз Касіскі: пошук повторів n-грам, відстаней та їх спільних дільників."""
    letters = [ch.lower() for ch in ciphertext if ch.lower() in UKRAINIAN_ALPHABET]
    text_clean = "".join(letters)
    patterns = {}
    for l in range(min_len, min_len + 2):
        for i in range(len(text_clean) - l):
            seq = text_clean[i:i+l]
            if seq not in patterns:
                pos = [m.start() for m in re.finditer(re.escape(seq), text_clean)]
                if len(pos) > 1:
                    patterns[seq] = pos

    distances = []
    for seq, pos in patterns.items():
        for i in range(len(pos) - 1):
            distances.append(pos[i+1] - pos[i])

    factor_counts = Counter()
    for dist in distances:
        for f in range(2, 21):
            if dist % f == 0:
                factor_counts[f] += 1
    return {
        "patterns_found": len(patterns),
        "distances_count": len(distances),
        "top_factors": factor_counts.most_common(5)
    }


def recover_caesar_shift(column_letters: list[str]) -> int:
    """Визначає зсув Цезаря для одного стовпця за критерієм мінімуму хі-квадрат."""
    n = len(column_letters)
    if n == 0:
        return 0
    counts = Counter(column_letters)
    best_shift, min_chi = 0, float('inf')
    for shift in range(ALPHABET_LEN):
        chi = 0.0
        for i, ch in enumerate(UKRAINIAN_ALPHABET):
            p_ch = UKRAINIAN_ALPHABET[(i - shift) % ALPHABET_LEN]
            observed = counts.get(ch, 0)
            expected = n * UKRAINIAN_FREQUENCIES.get(p_ch, 0.0001)
            chi += ((observed - expected) ** 2) / expected
        if chi < min_chi:
            min_chi = chi
            best_shift = shift
    return best_shift


def recover_vigenere_key(ciphertext: str, key_len: int) -> str:
    """Відновлює ключове слово заданої довжини key_len частотним методом."""
    letters = [ch.lower() for ch in ciphertext if ch.lower() in UKRAINIAN_ALPHABET]
    cosets = [[] for _ in range(key_len)]
    for i, ch in enumerate(letters):
        cosets[i % key_len].append(ch)
    return "".join(UKRAINIAN_ALPHABET[recover_caesar_shift(c)] for c in cosets)


# 1. СЛІПЕ ОЦІНЮВАННЯ ДОВЖИНИ КЛЮЧА
def estimate_key_length(ciphertext: str, max_d: int = 20) -> tuple[int, list[tuple[int, float]], int | None]:
    """
    Сліпе оцінювання довжини ключа за індексом збігу (IC) для d = 1..max_d.
    Вимога ТЗ:
    - Обчислити середній IC для d = 1..20.
    - Обрати найменше d, для якого IC >= max(0.042, 0.85 * max_ic).
    - Окремо показати оцінку за Касіскі (найчастіший дільник) та перевірити, чи вони збігаються.
    """
    ic_values = []
    for d in range(1, max_d + 1):
        ic = calculate_average_ic_for_period(ciphertext, d)
        ic_values.append((d, ic))

    max_ic = max(ic for _, ic in ic_values) if ic_values else 0.0
    threshold = max(0.042, 0.85 * max_ic)

    chosen_d = 1
    for d, ic in ic_values:
        if ic >= threshold:
            chosen_d = d
            break

    # Оцінка за Касіскі
    k_res = kasiski_examination(ciphertext)
    kasiski_top_d = k_res["top_factors"][0][0] if k_res["top_factors"] else None

    return chosen_d, ic_values, kasiski_top_d


# ----------------- КОНСОЛЬНЕ АВТО-ДЕМО -----------------
def run_auto_demo():
    print("=" * 82)
    print("      АВТОМАТИЧНА ДЕМОНСТРАЦІЯ: ЛАБОРАТОРНА РОБОТА № 4 (ШИФР ВІЖЕНЕРА)")
    print("=" * 82)

    # 1. Базове шифрування та дешифрування
    c_def = encrypt_vigenere(DEFAULT_TEXT, DEFAULT_KEY)
    p_def = decrypt_vigenere(c_def, DEFAULT_KEY)
    assert p_def == DEFAULT_TEXT, "Помилка: дешифрування правильним ключем не повернуло оригінал!"
    print(f"1. Базове шифрування відкритого тексту (довжина: {len(DEFAULT_TEXT)} симв.):")
    print(f"   Ключове слово: «{DEFAULT_KEY}» (довжина: {len(DEFAULT_KEY)})")
    print(f"   Шифротекст (перші 110 симв.): «{c_def[:110]}...»")
    print("✔ [Вбудована перевірка]: Дешифрування правильним ключем повернуло 100% оригінал.")

    # 2. Сліпий криптоаналіз (довжина ключа невідома алгоритму)
    print("\n2. СЛІПЕ ДОСЛІДЖЕННЯ ІНДЕКСУ ЗБІГУ (IC) ДЛЯ d = 1..20:")
    print("----------------------------------------------------------------------------------")
    print(f"{'Період d':<10} | {'Середній IC':<14} | {'Статус відносно порогу'}")
    print("----------------------------------------------------------------------------------")
    est_d, ic_list, kasiski_d = estimate_key_length(c_def, max_d=20)
    max_ic = max(ic for _, ic in ic_list)
    threshold = max(0.042, 0.85 * max_ic)

    for d, ic in ic_list:
        status = "Вище порогу (кандидат)" if ic >= threshold else "Розмито (поліалфавітний шум)"
        print(f"d = {d:2d}      | {ic:.4f}         | {status}")
    print("----------------------------------------------------------------------------------")
    print(f"Поріг детекції: max(0.042, 0.85 * {max_ic:.4f}) = {threshold:.4f}")
    print(f"Оцінена довжина за IC (найменше d >= порогу) : d = {est_d}")
    print(f"Оцінена довжина за методом Касіскі           : d = {kasiski_d}")
    match_status = "✔ ЗБІГАЮТЬСЯ" if est_d == kasiski_d else "РІЗНЯТЬСЯ"
    print(f"Зіставлення оцінок IC та Касіскі             : {match_status}")
    print(f"[Пост-перевірка для звіту]: Істинна довжина ключа: {len(clean_key(DEFAULT_KEY))}")

    # 3. Відновлення ключа за оціненою довжиною та чесний вердикт
    rec_key = recover_vigenere_key(c_def, est_d)
    decrypted_rec = decrypt_vigenere(c_def, rec_key)
    is_exact_match = (decrypted_rec == DEFAULT_TEXT)
    key_match = (rec_key.lower() == clean_key(DEFAULT_KEY))

    print(f"\n3. Відновлення ключового слова з оціненою довжиною d = {est_d}:")
    print(f"   Відновлений ключ : «{rec_key}»")
    print(f"   Істинний ключ    : «{clean_key(DEFAULT_KEY)}»")
    print(f"   Чесний вердикт   : {'✔ ПОВНИЙ ЗБІГ (текст та ключ відновлено 100%)' if is_exact_match else '✖ ЧАСТКОВИЙ/НЕ ЗБІГ'}")
    assert key_match, "Помилка: сліпий криптоаналіз не відновив дефолтний ключ!"

    # 4. Серія з 20 випадкових ключів довжини 2..14
    print("\n4. СЕРІЯ ТЕСТІВ: СЛІПИЙ КРИПТОАНАЛІЗ НА 20 ВИПАДКОВИХ КЛЮЧАХ (довжини 2..14):")
    print("==================================================================================")
    print(f"{'№':<3} | {'Істинний ключ':<16} | {'Довжина':<8} | {'Оцінка d':<9} | {'Відновлений':<16} | {'Статус'}")
    print("----------------------------------------------------------------------------------")

    len_success = 0
    key_success = 0
    random.seed(42)  # детермінована відтворюваність демонстрації

    for idx in range(1, 21):
        k_len = random.randint(2, 14)
        rand_k = "".join(random.choice(UKRAINIAN_ALPHABET) for _ in range(k_len))
        c_test = encrypt_vigenere(DEFAULT_TEXT, rand_k)

        cand_d, _, _ = estimate_key_length(c_test, max_d=20)
        cand_key = recover_vigenere_key(c_test, cand_d)

        d_ok = (cand_d == k_len)
        k_ok = (cand_key.lower() == rand_k.lower())

        if d_ok:
            len_success += 1
        if k_ok:
            key_success += 1

        status_str = "✔ Точно" if k_ok else ("Довжина ОК" if d_ok else "✖ Помилка")
        print(f"{idx:2d} | {rand_k:<16} | {k_len:<8} | {cand_d:<9} | {cand_key:<16} | {status_str}")

    print("==================================================================================")
    print(f"ПІДСУМОК СЕРІЇ: знайдено довжину {len_success}/20, ключ повністю {key_success}/20.")
    assert len_success >= 16 and key_success >= 16, f"Низька точність: довжина {len_success}/20, ключ {key_success}/20"
    print("✔ [Assert перевірка]: Критерій успішності сліпого розкриття виконано!")

    # 5. Приклад на короткому тексті (~150 літер) та пояснення обмеження
    print("\n5. ДОСЛІДЖЕННЯ ОБМЕЖЕННЯ МЕТОДУ НА КОРОТКОМУ ТЕКСТІ (~150 літер):")
    short_ct = encrypt_vigenere(SHORT_LIMITATION_TEXT, "СТУДЕНТ")
    short_d, _, short_kas = estimate_key_length(short_ct, max_d=15)
    short_rec_key = recover_vigenere_key(short_ct, short_d)
    short_success = (short_rec_key.lower() == "студент")

    print(f"   Короткий відкритий текст ({len(SHORT_LIMITATION_TEXT)} симв.): «{SHORT_LIMITATION_TEXT[:80]}...»")
    print(f"   Істинний ключ: «студент» (довжина 7). Оцінена IC довжина: {short_d}. Касіскі: {short_kas}")
    print(f"   Відновлений ключ на короткому тексті: «{short_rec_key}» (Успіх: {short_success})")
    print("\nОБМЕЖЕННЯ СТАТИСТИЧНОГО МЕТОДУ:")
    print("   На коротких текстах (< 200 символів) вибірка символів у кожному стовпці стає недостатньою (N/d < 25),")
    print("   через що статистичні флуктуації розмивають індекс збігу IC та заважають критерію хі-квадрат.")
    print("   Для гарантованого розкриття шифру Віженера довжина повідомлення повинна перевищувати")
    print("   довжину ключа щонайменше у 25–30 разів.")
    print("=" * 82)


# ----------------- ГРАФІЧНИЙ ІНТЕРФЕЙС (GUI TKINTER) -----------------
class VigenereGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Лабораторна робота № 4: Шифр Віженера (НУ «Львівська політехніка»)")
        self.root.geometry("920x820")
        self.root.minsize(800, 680)

        self.last_ciphertext = ""

        main_frame = ttk.Frame(root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            main_frame,
            text="Лабораторна робота № 4: Дослідження поліалфавітного шифру Віженера\n"
                 "Сліпий криптоаналіз  |  Тест Фрідмана (IC)  |  Метод Касіскі  |  Хі-квадрат",
            font=("Segoe UI", 11, "bold"),
            justify=tk.CENTER
        ).pack(pady=(0, 6))

        # 1. Текст
        tg = ttk.LabelFrame(main_frame, text=" 1. Відкритий текст (рекомендовано >= 500 символів) ", padding=6)
        tg.pack(fill=tk.BOTH, expand=False, pady=3)
        self.text_input = scrolledtext.ScrolledText(tg, height=3, font=("Segoe UI", 10), wrap=tk.WORD)
        self.text_input.pack(fill=tk.BOTH, expand=True)
        self.text_input.insert(tk.END, DEFAULT_TEXT)

        # 2. Ключ
        kg = ttk.LabelFrame(main_frame, text=" 2. Ключове слово ", padding=6)
        kg.pack(fill=tk.X, pady=3)
        ttk.Label(kg, text="Ключ:").pack(side=tk.LEFT, padx=4)
        self.key_entry = ttk.Entry(kg, width=24, font=("Segoe UI", 10))
        self.key_entry.insert(0, DEFAULT_KEY)
        self.key_entry.pack(side=tk.LEFT, padx=4)

        # G2. Поле шифротексту
        cg = ttk.LabelFrame(main_frame, text=" 3. Шифротекст (для вставки стороннього або перегляду результату) ", padding=6)
        cg.pack(fill=tk.BOTH, expand=False, pady=3)
        self.cipher_input = scrolledtext.ScrolledText(cg, height=3, font=("Consolas", 9), wrap=tk.WORD)
        self.cipher_input.pack(fill=tk.BOTH, expand=True)

        # 4. Кнопки дій
        bg = ttk.Frame(main_frame)
        bg.pack(fill=tk.X, pady=4)
        ttk.Button(bg, text="🔒 Зашифрувати", command=self.handle_encrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🔓 Дешифрувати", command=self.handle_decrypt).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="📈 Дослідження IC (d=1..20)", command=self.handle_friedman).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="🧩 Метод Касіскі", command=self.handle_kasiski).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="⚡ Сліпий злам (IC + χ²)", command=self.handle_recover_key).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)
        ttk.Button(bg, text="▶ Авто-демо", command=self.handle_auto_demo).pack(side=tk.LEFT, padx=2, expand=True, fill=tk.X)

        # 5. Вивід
        og = ttk.LabelFrame(main_frame, text=" 4. Протокол роботи, результати аналізу та дешифрування ", padding=6)
        og.pack(fill=tk.BOTH, expand=True, pady=3)
        self.text_output = scrolledtext.ScrolledText(og, font=("Consolas", 9), wrap=tk.WORD, bg="#F9F9F9")
        self.text_output.pack(fill=tk.BOTH, expand=True)

        self.log("Програма готова. Введіть відкритий текст або вставте шифротекст і натисніть потрібну дію.\n")

    def log(self, msg: str):
        self.text_output.insert(tk.END, msg + "\n")
        self.text_output.see(tk.END)

    def clear_output(self):
        self.text_output.delete("1.0", tk.END)

    def get_ciphertext_for_action(self) -> str | None:
        """Отримує шифротекст із спеціального поля, або fallback на останній результат."""
        c = self.cipher_input.get("1.0", tk.END).strip()
        if not c:
            c = self.last_ciphertext
        if not c:
            messagebox.showwarning("Помилка", "Поле «Шифротекст» порожнє! Спочатку зашифруйте текст або вставте криптограму.")
            return None
        return c

    def handle_encrypt(self):
        t = self.text_input.get("1.0", tk.END).strip()
        k = self.key_entry.get().strip()
        if not t or not k:
            messagebox.showwarning("Помилка", "Введіть відкритий текст і ключове слово!")
            return
        try:
            c = encrypt_vigenere(t, k)
        except Exception as e:
            messagebox.showerror("Помилка шифрування", str(e))
            return

        self.last_ciphertext = c
        self.cipher_input.delete("1.0", tk.END)
        self.cipher_input.insert(tk.END, c)

        self.log("=" * 72)
        self.log(f"🔒 ШИФРУВАННЯ ВІЖЕНЕРА (ключ «{k}», довжина {len(clean_key(k))}):")
        self.log(f"Шифротекст (перші 150 символів):\n{c[:150]}...")
        self.log("Шифротекст розміщено у полі введення шифротексту.")
        self.log("=" * 72)

    def handle_decrypt(self):
        c = self.get_ciphertext_for_action()
        if not c:
            return
        k = self.key_entry.get().strip()
        if not k:
            messagebox.showwarning("Помилка", "Введіть ключ для дешифрування!")
            return
        try:
            p = decrypt_vigenere(c, k)
        except Exception as e:
            messagebox.showerror("Помилка дешифрування", str(e))
            return

        self.log("=" * 72)
        self.log(f"🔓 ДЕШИФРУВАННЯ ШИФРОТЕКСТУ (ключ «{k}»):")
        self.log(f"Результат розшифрування:\n{p[:200]}...")
        self.log("=" * 72)

    def handle_friedman(self):
        c = self.get_ciphertext_for_action()
        if not c:
            return
        est_d, ic_list, kasiski_d = estimate_key_length(c, max_d=20)
        max_ic = max(ic for _, ic in ic_list)
        threshold = max(0.042, 0.85 * max_ic)

        self.log("=" * 72)
        self.log("ТЕСТ ФРІДМАНА: СЕРЕДНІЙ ІНДЕКС ЗБІГУ (IC) ДЛЯ d = 1..20:")
        self.log(f"{'Період d':<10} | {'Середній IC':<14} | {'Оцінка'}")
        self.log("-" * 72)
        for d, ic in ic_list:
            status = "Кандидат (вище порогу)" if ic >= threshold else "Шум (розмито)"
            self.log(f"d = {d:2d}      | {ic:.4f}         | {status}")
        self.log("-" * 72)
        self.log(f"Поріг детекції довжини: {threshold:.4f}")
        self.log(f"Оцінена алгоритмом довжина ключа: d = {est_d}")
        if kasiski_d:
            self.log(f"Оцінка за методом Касіскі        : d = {kasiski_d}")
        self.log("=" * 72)

    def handle_kasiski(self):
        c = self.get_ciphertext_for_action()
        if not c:
            return
        res = kasiski_examination(c)
        self.log("=" * 72)
        self.log("МЕТОД КАСІСКІ (АНАЛІЗ ПОВТОРЮВАНИХ ТРИГРАМ):")
        self.log(f"Знайдено патернів: {res['patterns_found']}, знайдено відстаней: {res['distances_count']}")
        self.log("Найчастіші дільники періоду:")
        for factor, cnt in res["top_factors"]:
            self.log(f"  Дільник d = {factor:2d} (зустрівся {cnt} разів)")
        self.log("=" * 72)

    def handle_recover_key(self):
        c = self.get_ciphertext_for_action()
        if not c:
            return
        est_d, _, kas_d = estimate_key_length(c, max_d=20)
        rec_k = recover_vigenere_key(c, est_d)
        dec_text = decrypt_vigenere(c, rec_k)

        self.log("=" * 72)
        self.log("⚡ СЛІПИЙ КРИПТОАНАЛІЗ (алгоритм не знає істинного ключа):")
        self.log(f"Оцінена довжина ключа (IC) : d = {est_d} (Касіскі: {kas_d})")
        self.log(f"Відновлене ключове слово   : «{rec_k}»")
        self.log(f"Розшифрований текст (фрагмент):\n«{dec_text[:160]}...»")

        # Перевірка з полем ключа (якщо користувач його ввів) як довідковий пост-чек
        user_k = clean_key(self.key_entry.get().strip())
        if user_k:
            is_match = (rec_k.lower() == user_k)
            self.log(f"[Пост-перевірка з полем ключа]: «{user_k}» -> {'✔ 100% ЗБІГ' if is_match else '✖ ВІДМІННІСТЬ'}")
        self.log("=" * 72)

    def handle_auto_demo(self):
        self.clear_output()
        self.log("▶ Запуск автоматичної демонстрації ЛР № 4...")
        self.handle_encrypt()
        self.handle_friedman()
        self.handle_kasiski()
        self.handle_recover_key()


def launch_gui():
    if not HAS_TKINTER:
        print("Графічний інтерфейс Tkinter недоступний у цьому середовищі.")
        print("Використовуйте режим автоматичної демонстрації: python crypto_labs/lab4_vigenere.py --demo")
        return
    root = tk.Tk()
    app = VigenereGUI(root)
    root.mainloop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("--demo", "-d", "demo"):
        sys.stdout.reconfigure(encoding="utf-8")
        run_auto_demo()
    else:
        launch_gui()
